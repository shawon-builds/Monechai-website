# What Sami needs to provide after local code work

Owner requested independent code/checks first, then this one checklist. Existing products stay. Guest buyers need no store account; only the owner has protected admin access. Registrar is Spaceship. Local code/tests are distinct from provider setup and accepting real orders.

## Current Supabase handoff — 2026-10-11

[All completed Supabase setup and exact remaining/resume steps](SUPABASE_SETUP_HANDOFF.md) are saved. New project `lmrdvenrchsnueztzcdi` is provisioned with13 migrations/16 RLS tables, scoped runtime role, products bucket/policies and initial Auth settings. Public key/origin and secret connections are already privately configured; don't request or paste them again. The existing Lead project stays untouched.

**PAUSED:** User will log into the friend's intended Gmail/Supabase and resume later. Designated store-admin email is unknown; **add it later**. Verify the friend can access this exact project before further actions. Actual owner bootstrap/MFA, custom SMTP/code template, real product/customer acceptance and production setup remain.

## 1. Backend and owner access — remaining identity dependency

The hosted backend and connection values below are already configured locally. The confirmed owner identity is pending. Keep the values in ignored environment/provider secret storage; do not create a duplicate project or post secrets in chat.

| Variable / input | Purpose | Where to obtain it | Public or secret |
|---|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Actual Auth/image API origin | Supabase project Connect dialog; configured HTTPS API origin if self-hosted | PUBLIC |
| `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | Public project key used with your own sign-in session | Supabase Connect / Settings → API Keys | PUBLIC; never use a service-role/secret key here |
| `DATABASE_URL` | Server database access | Connect; runtime role/grants reviewed per database-security.md | SECRET |
| `DIRECT_URL` when migration access is separate | Reviewed schema migrations/owner bootstrap | Connect direct/session connection with migration permissions | SECRET |
| Confirmed owner Auth email/user | Your admin login and whitelist identity | Authentication → Users; create the owner user in your account | Private identity/configuration; sign in personally |

Confirm the variable **names** are configured, and grant a scoped project/dashboard session or perform the dashboard steps yourself. The implemented login/media path needs no service-role key or new MCP server. App uses `.env.local` automatically through Next; standalone operations/migration commands need exported environment or Node22 `--env-file=.env.local` (Drizzle config does not load env files itself). Never share your login password, MFA code/QR/seed, wallet PIN, SSH private key or broad account password.

Migrations0000–0012 and the `products` bucket/restrictive owner-membership/AAL2 policies are already applied. Next create/bootstrap the real owner whitelist and perform actual login → authenticator setup → add draft → upload → publish → storefront → customer order → admin operations/revocation checks. Real photos are uploaded through admin; normal product entry requires no code edits. Local placeholder/demo records remain in place and are not silently published as real stock.

## 2. Domain and hosting

- **Exact purchased domain/desired canonical hostname**, and whether DNS is currently managed at Spaceship or elsewhere. `NEXT_PUBLIC_SITE_URL` is the PUBLIC canonical HTTPS origin, such as your actual chosen `https://…` hostname.
- Spaceship dashboard/DNS setup capability, or perform the record changes yourself. Domain registration can stay at Spaceship. No Cloudflare account/token is required unless those capabilities are selected.
- Tell me whether hosting already exists. Otherwise choose the host/backend route after we evaluate the actual commercial limits/cost and Bangladesh latency. No provider has been purchased by this code work.
- For a VPS: approved deploy user/host/SSH access via an authorized session or public-key grant. For a managed host: scoped project/collaborator access for builds/env/domain. GitHub write/Actions access to the correct repo is needed to push changes/run CI; intended repo visibility must be verified. No new broad token is necessary merely to discuss setup.

## 3. Real store/business information

Provide the actual public store name, hotline/support email/WhatsApp number and any public business address. Provide approved delivery areas, **fees**, estimated times, courier dispatch/tracking/COD settlement process, returns/refund/exchange/warranty rules, privacy and terms. Do not substitute guessed fees or legal/business promises.

The admin now has policy publishing fields; all four English policies are required before new checkout. Optional approved Bangla text is supported with an explicit English fallback. Each order records consent to a retained policy revision; customers must reaccept changed policies. Tell me how you want to confirm orders with customers (manual call/WhatsApp initially is supported by the operating plan; automatic customer SMS/email requires a selected channel/integration). Receipt URLs are bearer links: anyone with the private link can read its limited receipt, never customer name/phone/address. More sensitive customer lookup/history/edits requires separate verified ownership before implementation.

You can leave product assets for later admin entry: actual photos, EN/BN name/description, category, SKU/options, price and physical stock. Existing products are preserved; no need to re-upload everything just to configure the backend.

## 4. Mail, recovery, owner order alerts and operator alerts

One SMTP provider can supply both Supabase Auth mail and app/operator alerts, subject to its actual allowed sender/limits. Provide/authorize a verified sending domain/address and real recipient mailboxes.

| Value | Purpose and placement | Visibility / obtain from |
|---|---|---|
| SMTP host/port/user/password in **Supabase Auth SMTP settings** | Owner recovery email | Password SECRET; mail provider's SMTP credentials page |
| Reset password email template with `{{ .Token }}` | Six-digit recovery code for `/admin/recovery`; see admin-bootstrap.md. Dashboard currently requires custom SMTP before template editing. | Supabase Auth email templates; after SMTP configuration |
| `SMTP_HOST`, `SMTP_PORT` (465/587), `SMTP_USER`, `SMTP_PASSWORD` | App and operator SMTP delivery | SMTP password SECRET; server/private scheduler env only |
| `EMAIL_FROM` | Verified sender | Provider-approved address; public business sender |
| `ORDER_ALERT_EMAIL` | Owner order notifications | Your real private recipient mailbox |
| `OPS_ALERT_EMAIL` | Health/backup/worker failure alerts | Your real private recipient mailbox |
| `ORDER_WORKER_SECRET` | Authorizes private order-alert scheduler calls | SECRET; generate a random value of at least32 characters into server/scheduler secret storage |

You enroll the authenticator yourself; don't send its secret. We verify real recovery delivery, MFA, logout/revocation, queued order-alert retry and a deliberate operator incident after setup. Provider acceptance alone is not inbox delivery. Customer email collection/receipts are not implicitly enabled by configuring SMTP.

## 5. Backups and monitoring

Choose an **independent backup destination**, retention and acceptable data-loss/recovery windows. Provide scoped upload/storage authorization only for that destination; exact provider variables follow the chosen R2/S3/other route. Local encrypted export/restore code exists, but independent upload, actual full Supabase Auth/bucket/role recovery and host scheduling must be configured/tested with your provider. Keep encryption/recovery material separate from the stored backup.

- `BACKUP_DATABASE_URL`: SECRET scoped backup connection from backend/Connect.
- `BACKUP_OUTPUT_DIR`: private encrypted staging directory outside source/web paths.
- `BACKUP_SUPABASE_URL`: PUBLIC backend origin, normally same as `NEXT_PUBLIC_SUPABASE_URL`.
- `BACKUP_ENCRYPTION_PASSWORD`: SECRET strong independent phrase (at least20 characters), stored privately by you.
- `BACKUP_PG_IMAGE`: approved official CLI version matching actual PostgreSQL.
- `HEALTHCHECK_URL`: configured `/api/health` address for operator checks.
- Owner-controlled external uptime monitor and alert recipient; no mandatory vendor. Configure/test independent host/error incident detection and retention. [OPERATIONS_CHECKS.md](OPERATIONS_CHECKS.md) explains scripts, scheduler examples, scope and verified local restore boundary.

## 6. Online payment — provider choice required

Tell me **COD-only for initial launch, or COD plus online payments**, and whether you already have an approved gateway/merchant account. For online payments, supply the selected provider, merchant approval and sandbox access first; exact environment-variable names come from its official integration and go into server secret storage. Production gateway credentials/settlement/refund rules/callback domain follow sandbox validation. No wallet PIN/card credentials are needed by Monechai.

Goal11 tracks initiation/verification/notification/idempotency/expiry/inventory/reconciliation/refunds. No online payment UI is shipped as real functionality before integration. A buyer can pay as a store guest. SMS/phone OTP is only an additional decision if future customer data/history/edit features require it; current limited receipts don't silently create customer accounts.

## What can happen once these are ready

First connect the backend and your owner account; then enter approved store policies/rates/contact and real products/photos; verify actual owner/customer/security flows; configure host/domain/mail/backups/monitoring; complete gateway sandbox acceptance if selected; finally perform the separately authorized deployment/launch checks. Public values may be shared normally; secrets should be configured privately, then tell me the names are ready. No production readiness claim follows from merely supplying keys.
