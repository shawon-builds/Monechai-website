# Monechai store, checkout, privacy and payment plan

Owner discussion and implementation authorization: 2026-10-11. This is the durable record of the product/account/payment Q&A, not a claim of live setup. Owner asks to finish independent code/local checks first, then provide one consolidated owner setup checklist. Preserve all existing catalog records; do not remove products as cleanup.

## Business and two website areas

- Single owner, Sami, selling new products only across Bangladesh. No multi-seller accounts, commissions or payouts.
- Public storefront for products/search/cart/guest checkout and a limited private order receipt.
- Protected `/admin` for owner product/category/photo/stock/order/settings management. Authentication plus server-side membership checks are required at every privileged operation.
- Buyers do not need a Monechai account. Payment-provider authorization is separate from a store account. Optional customer accounts/saved addresses/history are future scope.
- Domain purchased at Spaceship; keeping registration there is compatible with a separate app host and Supabase backend. Hosting/backend/DNS setup is unverified.

## Adding and managing products

Owner signs in → Products → New → enters category, English/Bangla text, unique slug/product SKU, BDT price, first variant SKU/label and total stock → saves a draft → uploads photos/adds variant options → selects primary photo → publishes. Product creation does not require source edits.

- Slug is the readable product URL part; SKU is an internal unique product/option code.
- Variant means a purchasable option such as color/size, with independent stock and optional price override. One Default variant is sufficient for a product with no options.
- Stock edits set the total available quantity, not an increment. Server transactions enforce inventory at purchase. Past orders preserve immutable names/options/prices.
- Drafts are private. Publishing requires a verified current primary photo and an active variant. Published tracked zero-stock products are unavailable to purchase.
- Categories are managed in admin. Unpublishing/archiving hides a product without rewriting past orders.
- Existing products stay. Existing demo records remain unverified drafts and cannot be published as real merchandise; create separate real listings with approved assets.

## Images and backend

Upload through the product's admin edit page; the app writes image bytes to Supabase Storage and links/order/primary metadata to PostgreSQL. JPEG/PNG/WebP input, 5 MiB/file, ten photos/product; bounded real decoding and WebP normalization. No routine direct bucket upload or separate image vendor is required.

Current stack needs one working Supabase backend (hosted or independently provisioned self-hosted): PostgreSQL for products/orders/settings, Auth for owner identity, Storage for product images. Local tests use disposable PostgreSQL and image/policy adapters, not an accepted owner project. Independent backups must include database and photo bytes.

## Buyer separation and privacy

- No public order list or lookup of full customer records by sequential ID/order number/phone.
- Separate database order rows and browser-specific cart/recovery state. Cart storage contains variant IDs/quantities, not permanent name/phone/address/payment credentials.
- Limited receipts use random 256-bit bearer links and expose purchased items, amounts, status and optional courier reference, never name/phone/address/note.
- Anyone holding a private receipt URL can read that limited receipt. This is not identity verification. Protect responses from shared caches/referrer leakage/indexing and do not log tokens. On a shared browser, the next user can see the saved cart or retained receipt link.
- Full customer information is restricted to authorized owner admin operations.
- Phone OTP or another verified ownership mechanism is required before any future customer address display, order edits, phone-based lookup or past-order history. OTP/customer accounts are not silently added to the current limited receipt scope.
- Regression coverage must verify unrelated receipt tokens, nonexistent/invalid tokens, PII omission and denied admin/database access. Live provider checks remain separate.

## Payments

Owner mail code now has a transactional leased/retry queue and TLS SMTP worker, with private admin queue/status/retry controls. Configure sender/owner mailbox/worker scheduler and verify delivery before acceptance; no real email has been sent. Customer confirmation channel remains owner-approved manual call/WhatsApp or a separately integrated provider.

COD remains the real implemented method: create transactional order with pending payment, courier collects, owner records verified collection/failed collection/refund through authorized audited transitions. No fake bKash/Nagad/card buttons.

Online payments are a provider-gated milestone (goal 11). Choose approved gateway/merchant onboarding before provider-specific implementation. Examples to evaluate are SSLCommerz or direct bKash; their eligibility, methods, fees and settlement terms require current owner/provider verification.

Online integration must: calculate amount server-side; create pending order/payment attempt; hand off to provider-hosted checkout; validate transaction/order/amount/currency server-side before paid; safely handle redirects, callbacks, retries, duplicate notifications, failures, expiry, stock reservation/release, reconciliation and refunds. Browser redirects/screenshots/entered transaction IDs cannot prove payment. Do not collect wallet PINs/card credentials in Monechai.

Supabase persists records; the payment provider moves money. A buyer can pay as a store guest. Real gateways require merchant approval and scoped secret credentials; generic code does not establish a working integration.

## Ownership and next setup

- Goal 04: guest checkout/recovery/receipt privacy; goal 05: owner Auth/recovery/MFA; goal 06: product/media admin.
- Goal 07: delivery/COD/order notification operations; goal 08: locale/SEO/branding/policies/security.
- Goals 09/10: local checks/CI/deployment/backup/alerts; goal 11: selected real online gateway.
- Exact existing/planned credentials and public/business inputs: [ACCESS_REQUIRED.md](ACCESS_REQUIRED.md). Account passwords, wallet PINs, OTPs, MFA seeds/recovery codes and secrets must not be pasted in chat or committed. Secrets belong in ignored local env/provider secret storage. Owner can perform dashboard setup without sharing a password.
- Owner will supply accounts, credentials, policies and assets after independent code/local work is complete. No provider account purchase, DNS change, real payment or deployment is implied by local fix authorization.

Official payment reference: [SSLCommerz integration](https://sslcommerz.com/integration-document/) and [validation](https://developer.sslcommerz.com/docs.html); [bKash merchant information](https://www.bkash.com/en/business/merchant).
