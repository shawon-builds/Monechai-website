# Production services, tools and hosting decision

Research date: **2026-10-11**. Prices/limits are vendor snapshots, not a purchase quote. Recheck the chosen billing region, commitment/renewal price, tax, inventory and usage allowances immediately before ordering.

## Owner requirements and current decision

- Monechai is a **single-owner resale store**; only Sami sells **new products**, delivered across Bangladesh.
- Owner confirmed the domain is **already purchased**. Registrar is Spaceship per owner; exact hostname/DNS authorization still need verification; no domain purchase is needed for this plan.
- Owner requires **complete production readiness**, rather than a working demo or a build that passes locally.
- Owner asked for the **cheapest viable hosting**, including genuine free options; Linux VPS is a candidate. No hosting provider, paid plan, self-hosted Supabase deployment or purchase has been authorized/selected by this document.
- Current code uses Next.js/Node, PostgreSQL/Drizzle and implemented Supabase Auth/Storage adapters. Actual owner Auth/Storage acceptance is unverified. Existing deployment docs assume managed Supabase. Self-hosting needs its own operations artifacts and acceptance before replacing that runbook.
- COD is the current implemented payment scope. Courier operations are required; an automated courier API and online payment gateway are separate choices.

## Actual integration status and access

See [remaining implementation and exact access required](ACCESS_REQUIRED.md) for the current checklist. Local fixes used disposable PostgreSQL, dummy browser fixtures, a local media adapter and modeled SQL identities. No owner Supabase backend has been connected/accepted. Recovery/MFA, policy consent, SMTP owner outbox and operations/backup/monitoring job code now exist and pass local checks. Actual account/SMTP/scheduler/independent upload/full-backend restore and recipient acceptance remain. Turnstile is optional provider-gated scope. See OWNER_SETUP_CHECKLIST.md and OPERATIONS_CHECKS.md; independent code is finished, awaiting owner setup.

Fresh read-only GitHub checks on 2026-10-11: CLI user `Sami-754`, target `contactshawonhasan-oss/Monechai-website` PUBLIC with READ/pull only, no push/admin. This differs from the historical private/owner-access checkpoint. Owner authorization/intended visibility must be verified before release/CI; no remote changes were made.

## Hosting comparison

| Route | Published starting cost / limitations | Fit for this project |
|---|---|---|
| Netlify Free + Supabase Free | $0 within allowances. Netlify Free currently has 300 monthly credits and pauses projects if allowance is exhausted. Supabase Free can pause after low activity; managed downloadable backups are limited. | A genuine free development/preview route and possible tiny-store launch with explicitly accepted limits. Not the default dependable production recommendation. Current Next adapter, session, PostgreSQL transactions and quotas must be tested. |
| Linux VPS + self-hosted Supabase | Example: OVH Worldwide advertises an 8 GB / 4-vCore VPS-2 from **$8.50/month**, with IPv4 and daily VPS backup listed as included. More server administration and backup work. | Lowest recurring-bill candidate worth evaluating while preserving the stack. Start evaluation at 8 GB total RAM, benchmark the app and selected backend services. Full Supabase official minimum is 4 GB / 2 cores / 40 GB SSD; recommended 8 GB+ / 4 cores+ / 80 GB+ SSD. OVH example has 75 GB disk, below the recommended 80 GB, so storage capacity/upgrade must be checked. Not a validated capacity guarantee. |
| Small Linux VPS + Supabase Pro | Example: OVH advertises 4 GB VPS-1 from **$4.54/month**; Supabase Pro starts **$25/month** for one Micro instance within included compute credit. Combined starting arithmetic: **$29.04/month**, before relevant tax/usage/add-ons. | Lower database maintenance burden, close to current architecture/runbook. Database and Auth/Storage are managed; app/VPS still needs operations. Provider regional/term prices and available capacity must be verified. |
| Netlify Free + Supabase Pro | Backend starts **$25/month**, host remains $0 within 300-credit hard cap. Netlify Personal starts $9/month if upgrading host. | Cheap managed backend route, but free host exhaustion can still interrupt orders. A production assessment must include traffic/deploy estimates and an upgrade response, or choose paid hosting. |
| Cloudflare Workers | Free: 100,000 requests/day and 10 ms CPU per invocation. Paid starts **$5/month**, plus excess usage. Database/Auth/Storage costs are additional. | Not a drop-in replacement for this standalone Node app. Adapter, Postgres connection lifecycle, proxy/Auth, transactions, image handling and CPU behavior must be proven. Current Cloudflare guide defaults to beta vinext; OpenNext also documents Next 16 support. Do not migrate the runtime solely on a pricing headline. |
| Vercel Hobby | $0, **non-commercial personal use only**. | Exclude for the real commercial resale store. Paid Vercel would need its own total-cost comparison. |
| Render Free | Web service sleeps after 15 minutes without traffic; free PostgreSQL expires after 30 days. | Useful for experiments; not the production order database/hosting baseline. |
| Railway Free / trial | Free includes $1 monthly usage; trial is $5 one-time for 30 days; Hobby starts $5 with usage-based billing. | Does not establish a zero-cost always-on shop. A measured resource estimate is needed before claiming the $5 tier covers the app/database. |
| Oracle Always Free | Free compute depends on available capacity; idle instances can be reclaimed. | An opportunistic experiment, not the launch dependency for customer orders. |

**Recommendation:** evaluate an **8 GB-class paid Linux VPS with self-hosted Supabase** if minimizing the recurring bill is the priority and the owner accepts ongoing server/database maintenance. Use roughly **$10–15/month as a provisional planning allowance**, not a guaranteed all-in quote. The managed alternative starts around **$29–30/month** before extras. Do not buy a server before checking account/billing eligibility, region, storage, renewal/term conditions and a recovery design.

A second low-cost benchmark is Hetzner EU CX33: published June-2026 price **€8.49/month** plus **€0.50 IPv4** = **€8.99**, excluding VAT/backups. Its vendor listing specifies 4 vCPU / 8 GB / 80 GB. However the scraped product page reports unavailable and omits checkout prices, so it is not a verified orderable offer. Official server backup option adds 20% of server price. EU prices are not Singapore quotes; test Bangladesh latency to the selected origin and keep app/database colocated where practical.

Existing domain acquisition is excluded from monthly hosting estimates; renewal remains an annual operating cost. Courier charges, business mailbox, SMS, larger backup retention, optional PITR, traffic overages, taxes/FX and provider upgrades are not included. Free email/monitoring/backup allowances are usage caps, not unlimited services.

## External accounts and services

Capabilities below are required for the intended production operation. Specific vendors are recommended candidates, not installed/authorized integrations.

| Capability | Proposed tool/service | Readiness requirement | Cost approach |
|---|---|---|---|
| Domain / DNS | Existing registrar + Cloudflare DNS | Verify ownership, renewal, DNS access and canonical host. Preserve any email records. | Domain bought; Cloudflare Free candidate. |
| App hosting | One paid Linux VPS; Netlify as free preview candidate | Build artifact deploy, restart, updates, health checks, capacity and rollback tested. | Pay only for chosen host; do not provision two production hosts unnecessarily. |
| Database | Supabase PostgreSQL, hosted or self-hosted | Reviewed migrations, least-privilege runtime role, secured API permissions, persistent storage and tested restore. | Self-hosted shares VPS cost; hosted Pro starts $25. |
| Admin identity | Supabase Auth from the same backend | Bootstrap owner, member/nonmember/revocation/logout, MFA and working recovery flow. Close public registration where unneeded. | No separate identity vendor required. |
| Product images | Supabase Storage from the same backend | Real image upload/delete/order/primary/publish, authorization, file validation and photo recovery tested. | No separate Cloudinary service required for current scope. |
| Bot/abuse protection | Cloudflare Turnstile + application rate limits | Server-side token validation, hostname/action checks, durable retry handling and rate-limit tests. Keep normal customer checkout usable. | Turnstile Free supports businesses/production. |
| Email delivery | Resend via custom SMTP | Verified sender domain, SPF/DKIM/DMARC, admin recovery/invite delivery. Owner order-alert workflow where implemented. | Free currently 3,000 emails/month, max 100/day; monitor delivery failures/limits. |
| Support mailbox | Existing real mailbox or mailbox provider | Owner must receive/reply to support and monitoring alerts. Sender/API email service is not a full mailbox. | Existing mailbox can avoid a new subscription. |
| Backup destination | Private Cloudflare R2 Standard bucket, or equivalent independent target | Encrypted DB and photo copies, retention/last-success checks, separate credentials and actual restore drill. | R2 Standard free allowance: 10 GB-month, 1M Class A / 10M Class B operations; overages charged. |
| Uptime alerts | UptimeRobot | External site/health monitor and verified alert delivery to owner. | Vendor currently allows commercial use on Free: 50 monitors, 5-minute checks. |
| Error tracking | Sentry Developer, plus structured server logs | Capture server/checkout errors with PII/token redaction; trigger a test incident and verify alert. | Developer currently $0/one user, limited event quota; validate chosen plan during setup. |
| Source / release gates | GitHub private repo + GitHub Actions | Required lint/typecheck/unit/DB/E2E/build/security gates; isolated CI test DB, production secrets separated, release/rollback procedure. | Included CI usage first; track private-repo billing/limits. |
| Delivery / COD settlement | One Bangladesh courier merchant account; Pathao is one candidate | Owner-approved rates, pickup/dispatch, tracking reference, refused/returned parcel process, COD settlement reconciliation. | Shipment/COD service fees are operational costs. Portal/manual entry can precede API automation. |
| Customer support contact | Owner's WhatsApp/phone | Working contact links and business support details. | Basic click-to-chat needs no WhatsApp Business API credentials. |

Supabase's default SMTP is explicitly not intended for production. A custom SMTP provider is required for reliable production Auth email; account recovery code exists; its actual template/SMTP/session acceptance remains. Resend supports Supabase SMTP directly. Customer checkout currently has no email field, so email-provider signup alone does not create customer receipts; choose/use the actual customer notification channel explicitly.

Supabase database backups exclude Storage object bytes. A paid plan or VPS snapshot does not replace a tested database-and-photo recovery process. A single VPS has a shared failure domain for app/backend; it can be operated as a small production store, but it is not high availability. If the required uptime or acceptable data-loss window demands redundant infrastructure/PITR, scope and budget those capabilities explicitly.

## Build and operating tools

These are software utilities, not additional paid customer-facing services:

| Tool | Purpose | Current local inventory |
|---|---|---|
| Supported Node.js LTS + npm | Build/run Next.js and scripts | Installed. Deployment currently targets Node 22; audit host used Node 24.16.0. Pin/validate chosen runtime. |
| Git + GitHub CLI (`gh`) | Source and release administration | Installed; account authorization not rechecked here. |
| Docker Engine + Compose | Reproducible app, test DB and optional self-hosted backend | Installed; Compose 5.6.0 found. No production host provisioned. |
| PostgreSQL + Drizzle ORM/Kit | Transactions, schema and reviewed migrations | npm packages already declared; disposable Docker DB available for local checks. |
| Playwright + Chromium | Browser regression/checkout/admin verification | Already declared and installed during audit. Missing scenarios still need tests. |
| TypeScript / ESLint / dependency audit | Static/security release gates | Already declared; audit found development-tool advisories to resolve. |
| Nginx + Certbot/Let's Encrypt | VPS reverse proxy and automatically renewed TLS | Not on this workstation; existing Nginx template. Install/validate on selected VPS. Caddy is an alternative, not an additional requirement. |
| Supabase CLI | Local backend tooling/exports where useful | Not installed; optional until needed. Drizzle remains the app migration authority. |
| `pg_dump` + encrypted backup tool, e.g. restic | Database export and independent encrypted retention | Not installed on this workstation; can run in version-matched containers. Selected backup flow must include Storage files. |
| systemd timers/cron | Backup jobs, maintenance/heartbeat | Configure on selected host or a controlled external scheduler. No separate automation SaaS is necessary. |
| Cloudflare Wrangler | Workers deployment only if that route is selected | Not required for the ordinary VPS route. |

No MCP server is required for store operation. Official provider connectors/CLIs may help development/administration, but introduce them only for an actual task and scoped authorization. Firecrawl/web research tools are development aids and are not store runtime dependencies.

## Credentials and where they belong

Current app variables are the first five rows. Future integration variables are **proposed names** until the relevant implementation lands; they are not secretly already supported by this app.

| Value / proposed name | Purpose / obtain from | Visibility and placement |
|---|---|---|
| `DATABASE_URL` | Runtime DB connection: hosted Supabase Connect, or configured private self-hosted PostgreSQL endpoint | SECRET, app runtime only; use scoped DB role. |
| `DIRECT_URL` (optional) | Migration connection: hosted Connect or private migration endpoint | SECRET, migration job only; not Docker build args. |
| `NEXT_PUBLIC_SUPABASE_URL` | Auth/Storage origin: hosted Connect dialog or self-hosted HTTPS API origin | PUBLIC, build and runtime. |
| `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | Hosted Connect / Settings → API Keys, or compatible public key from selected self-hosted setup | PUBLIC, build and runtime; never insert privileged server key. |
| `NEXT_PUBLIC_SITE_URL` | Verified canonical domain origin | PUBLIC, build and runtime. |
| `DATABASE_SSL` | Chosen secure DB transport; current hosted setting `require` | Configuration, not secret. Review self-hosted private-network/TLS setup; never expose an unsecured public DB. |
| `NEXT_PUBLIC_TURNSTILE_SITE_KEY` / `TURNSTILE_SECRET_KEY` | Cloudflare Dashboard → Turnstile widget | Site key PUBLIC; secret SERVER ONLY. Planned integration. |
| Resend SMTP host/port/user/password | Resend account and verified domain; password is scoped API key | Password SECRET in Supabase SMTP settings; app `RESEND_API_KEY` only if direct mail API implemented. |
| `RESEND_API_KEY`, `EMAIL_FROM`, `ORDER_ALERT_EMAIL` | Planned server-side owner alerts: Resend API keys / verified sender / owner recipient | API key SECRET; sender config public business info, recipient operational/private. |
| `R2_ENDPOINT`, `R2_ACCESS_KEY_ID`, `R2_SECRET_ACCESS_KEY`, `BACKUP_BUCKET`, `BACKUP_ENCRYPTION_PASSWORD` | Cloudflare R2 bucket-scoped S3 credentials plus independent backup encryption secret | Credentials/encryption secret SECRET in backup job; never grant app general backup access. Names finalized with chosen backup tool. |
| `SENTRY_DSN` / `NEXT_PUBLIC_SENTRY_DSN`, `SENTRY_AUTH_TOKEN` | Sentry project client key and source-map upload authorization | DSN is client-visible endpoint; auth token SECRET, CI/build only. Planned integration. |
| `CLOUDFLARE_API_TOKEN` (only for API automation) | Account → scoped API tokens | SECRET in deploy job; manual dashboard DNS setup does not need it in app. |
| Deployment SSH key / `DEPLOY_HOST`, `DEPLOY_USER`, `DEPLOY_SSH_KEY` | Chosen VPS account / owner-created scoped deploy user | SSH key SECRET in protected CI/deploy environment; never ask owner to paste login passwords into chat. |
| GitHub authorization | Owner's approved `gh` login or scoped deploy app/token | SECRET/account authorization; app runtime does not need a GitHub token. |
| Courier credentials | Selected merchant portal, only when API integration is selected | SECRET, provider-specific names; not invented before provider selection. |
| Self-hosted backend secrets | Generate/set according to pinned official Supabase deployment instructions | SECRET server/backend environment; do not reuse demo/default keys. Their full list belongs in the selected deployment implementation. |

No Supabase service-role/secret key is required by the implemented Auth or normal media adapter. Image writes use the authenticated owner's session and reviewed Storage policies. Owner-authorized dashboard/DNS setup is still required; that is not an app environment variable. Current official locations: [Supabase API keys](https://supabase.com/docs/guides/api/api-keys) and [database Connect dialog](https://supabase.com/docs/guides/database/connecting-to-postgres).

## Production acceptance gates

Owning goals remain 01–10; this document adds the service/setup/recovery details, not a new parallel project.

- [ ] Choose the host/backend route with verified total recurring cost, capacity, region and ownership. Domain is purchased; DNS/canonical configuration still pending.
- [ ] Fix all launch-blocking findings in `PROJECT_AUDIT.md`, including Data API permissions, product upload/publish, cancellation stock and durable checkout retries. Do not close them because services were purchased.
- [ ] Use isolated staging/test data. Validate the selected real Auth/Storage/backend without customer PII in fixtures; run full member/nonmember/logout/revocation/MFA/recovery checks.
- [ ] Execute owner create→upload→publish→customer order→fulfillment/cancellation/return→COD reconciliation with correct prices, stock and fees.
- [ ] Validate checkout abuse controls, shared/durable rate limits, CSRF/origin/proxy behavior and secret/client boundaries on the actual HTTPS host.
- [ ] Verify a backup contains DB and product photo bytes, choose recovery/data-loss targets with owner, restore to an isolated environment and measure actual recovery. Schedule and alert on backup failures.
- [ ] Deliver a test admin recovery email and owner order/incident alert; verify support mailbox and customer confirmation/contact flow.
- [ ] Verify external health/uptime/error alerts, log rotation/redaction, restart after reboot, certificate renewal, resource/disk/usage alerts and rollback.
- [ ] Run required CI/local DB/admin/media/browser/build/security gates and documented mobile/desktop/EN/BN checks; resolve unsupported/vulnerable tooling.
- [ ] Confirm real catalog/condition information, business contact, shipping/returns/privacy terms and courier process. COD-only launch does not require an online gateway.
- [ ] Confirm every required goal's definition of done before declaring the project production ready. Owner-owned purchase/deploy actions still need their actual authorization.

## Sources verified during this research

- [Netlify commercial Free plan statement](https://www.netlify.com/blog/introducing-netlify-free-plan/) (2024 announcement; use current docs for limits), [current credit plans](https://docs.netlify.com/manage/accounts-and-billing/billing/billing-for-credit-based-plans/credit-based-pricing-plans/), [pause behavior](https://docs.netlify.com/manage/accounts-and-billing/billing/resume-paused-projects/), [Next adapter](https://docs.netlify.com/build/frameworks/framework-setup-guides/nextjs/overview/).
- [Vercel Hobby commercial restriction](https://vercel.com/docs/plans/hobby), [Render Free limits](https://render.com/docs/free), [Railway pricing](https://docs.railway.com/pricing/plans), [Oracle reclaim policy](https://docs.oracle.com/en-us/iaas/Content/FreeTier/freetier_topic-Always_Free_Resources.htm).
- [OVH Worldwide VPS prices/specs](https://www.ovhcloud.com/en/vps/) (currently labels the range “VPS 2027”; quote/region/term not checked), [Hetzner June 2026 price adjustment](https://docs.hetzner.com/general/infrastructure-and-availability/price-adjustment/), [CX specs/availability](https://www.hetzner.com/cloud/cost-optimized/), [IPv4](https://docs.hetzner.com/cloud/servers/primary-ips/overview/), [backup billing](https://docs.hetzner.com/cloud/billing/faq/).
- [Supabase pricing](https://supabase.com/pricing), [production checklist](https://supabase.com/docs/guides/deployment/going-into-prod), [self-hosted resource requirements](https://supabase.com/docs/guides/self-hosting/docker), [SMTP restrictions](https://supabase.com/docs/guides/auth/auth-smtp), [database backup/object exclusion](https://supabase.com/docs/guides/platform/backups).
- [Workers pricing](https://developers.cloudflare.com/workers/platform/pricing/), [current Next runtime guide](https://developers.cloudflare.com/workers/framework-guides/web-apps/nextjs/), [OpenNext support](https://opennext.js.org/cloudflare), [Turnstile plans](https://developers.cloudflare.com/turnstile/plans/) and [required server validation](https://developers.cloudflare.com/turnstile/get-started/server-side-validation/), [R2 allowance](https://developers.cloudflare.com/r2/pricing/).
- [Resend pricing](https://resend.com/pricing) and [Supabase SMTP](https://resend.com/docs/send-with-supabase-smtp), [Sentry pricing](https://sentry.io/pricing/) and [Next SDK](https://docs.sentry.io/platforms/javascript/guides/nextjs/) (web open failed; official page retrieved using Firecrawl), [UptimeRobot commercial Free plan](https://help.uptimerobot.com/en/articles/11604710-who-should-use-uptimerobot-s-free-plan), [GitHub Actions](https://docs.github.com/en/actions/get-started/quickstart), [Pathao courier/merchant operations](https://pathao.com/courier/).

No provider account was created, paid plan enabled, DNS changed, email sent, tool installed, app implementation changed, or production test executed during this research.
