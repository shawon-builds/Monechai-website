# Monechai — remaining work and external access required

Current owner handoff: [OWNER_SETUP_CHECKLIST.md](OWNER_SETUP_CHECKLIST.md). Latest implementation/operations: [STORE_OPERATING_PLAN.md](STORE_OPERATING_PLAN.md) and [OPERATIONS_CHECKS.md](OPERATIONS_CHECKS.md). Older proposed vendor-specific variables below are historical options, not a requirement to open every vendor account.

Updated **2026-10-11** after the owner asked how fixes were possible without providing Supabase credentials. This is an access and readiness checklist; owner resumed independent implementation on 2026-10-11; external setup follows local code/checks. No accounts were created, connected, purchased or changed for this clarification.

## What happened without provider access

The workspace already provides Node/npm, Git, Docker and browser-test tooling. A disposable local PostgreSQL 17.10 database held dummy products, delivery settings and orders. Tests exercised real SQL migrations, transactions, stock, order recovery and permission denial against that local database.

Image tests decoded real sample files and used a local object-store adapter; Storage policies were checked with modeled SQL identities. Admin policy tests do not establish a real Supabase Auth session. Customer browser fixtures inserted catalog data directly, so they do not prove the owner upload/publish journey.

**No owner Supabase project has been connected or verified.** Auth/Storage integration code and policy artifacts are written, but actual setup and acceptance remain blocked. There is no claim of a working production integration. The stopped local test database and restart details are in [STATS.MD](../STATS.MD).

## Remaining work

The [audit's current resolution table](PROJECT_AUDIT.md) records16 FIXED_LOCAL findings,A15 CLOSED_SCOPE and four unresolved IDs (A16/A17/A18/A21):

| ID | Remaining implementation / acceptance |
|---|---|
| A16 | Policy authoring/pages/immutable consent and durable SMTP owner-alert code pass locally. Actual approved policies/rates/ETA/contact, mailbox/inbox/scheduler and customer contact workflow remain. |
| A17 | Actual Auth member/nonmember/logout/revocation, owner create/upload/publish/storefront and customer/order/admin/return journeys; real-image/locale/visual/accessibility verification. |
| A18 | Production audit0; esbuild override removed4 moderate. Full5 high unpatched braces-chain/version entries remain despite reviewed string-pattern mitigation; ESLint10/React-plugin compatibility also upstream. No credentials resolve this gate. |
| A21 | CI/strict tests/runtime/ops/SMTP/scheduler/Docker/nginx code checked locally. Actual host/DNS/TLS/mail/GitHub execution/off-site upload/full-backend restore/monitoring/inbox/launch acceptance remain. |

Owner password-recovery/TOTP/AAL2 code now exists; actual SMTP template/provider/enrollment/recovery acceptance remains. SMTP/backup/monitoring job code now exists; actual providers/independent upload/full-backend restore/schedules/inbox acceptance remain. Turnstile is optional if retained. Keys alone do not complete provider acceptance. Goals 05/06/07 remain blocked on actual owner/backend acceptance even where local code fixes passed.

## 1. Backend: Supabase PostgreSQL, Auth and Storage

Provide one usable backend: a hosted Supabase project, or a self-hosted Supabase installation on the selected VPS. Hosted account access is not required if the self-hosted route is selected; that route needs its own provisioning and secret configuration first. Prefer isolated staging data for acceptance.

| Value/access | Purpose | Obtain from | Visibility / placement |
|---|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Auth and product-image API origin | Hosted project's Connect dialog; otherwise configured self-hosted HTTPS API origin | PUBLIC; current app supports it, build and runtime. |
| `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | Public client key used with the signed-in user's session | Hosted Connect or Settings → API Keys; compatible public key for selected self-hosted setup | PUBLIC; current app supports it, build and runtime. |
| `DATABASE_URL` | Server catalog/orders/settings connection | Hosted Dashboard → Connect, selecting the appropriate connection; provision a scoped runtime role | SECRET; app runtime, never a public variable. |
| `DIRECT_URL` if a separate migration connection is used | Apply reviewed schema migrations | Connect dialog, direct or suitable session connection with migration privileges | SECRET; migration environment. Current migration tooling supports it. |
| Owner dashboard/administrative setup capability | Auth settings, first-admin bootstrap, Storage bucket/policies and permissions review | Owner-authorized project session or scoped project access; owner may perform the setup steps | Account authorization; no app variable needed. |
| Confirmed owner Auth user/email | Actual login and admin whitelist | Authentication → Users; [bootstrap instructions](admin-bootstrap.md) | Owner signs in personally; do not collect password or MFA seed/recovery codes. |
| `products` Storage bucket and real photos | Actual upload/primary/reorder/delete/publish acceptance | Storage dashboard, [image setup](product-images.md), reviewed `ops/supabase-storage.sql` | Existing backend and owner assets; no separate image vendor needed. |

Current official key instructions use **Settings → API Keys** or **Connect**. See [Supabase API keys](https://supabase.com/docs/guides/api/api-keys) and [database connection methods](https://supabase.com/docs/guides/database/connecting-to-postgres). Database transport (`DATABASE_SSL`) and connection mode are chosen with the deployed network.

**The implemented login/normal image flow does not require a Supabase secret/service-role key.** It uses the public project key plus the authenticated owner session. A Supabase account access token/MCP connection is optional administration tooling, not required to run the store.

## 2. App hosting

Choose one deployment route before collecting provider-specific credentials. No provider has been selected/provisioned.

- **Linux VPS:** host/IP, SSH port, a deploy user authorized for the required setup, and SSH access through an owner-approved key/session. Deployment needs Docker/Node, persistent backend storage if self-hosting, proxy/TLS, restart/updates, backups and health checks.
- **Managed host:** owner-authorized project dashboard/CLI access and permission to configure builds, domain and environment values instead of VPS SSH.
- `DEPLOY_HOST`, `DEPLOY_USER`, `DEPLOY_SSH_KEY` are proposed CI names, not an existing deployed pipeline. Any SSH private key is SECRET and belongs in protected local/CI credential storage.

The [hosting research](PRODUCTION_SERVICES.md) has the cost/limit comparison; published prices are not an order or a selected plan.

## 3. Domain / DNS / Cloudflare

Owner confirmed on 2026-10-11 that the purchased domain is registered at **Spaceship**. Actual hostname, active nameservers/DNS records and account setup access have not been verified in this clarification. Registrar choice does not select app hosting or require Cloudflare.

Need the actual purchased domain, canonical HTTPS hostname, registrar/DNS provider and authority to set its records. `NEXT_PUBLIC_SITE_URL` is PUBLIC and already supported by the app. DNS access also enables sender verification and TLS setup.

Owner dashboard setup is sufficient. If automating Cloudflare DNS, use a zone-scoped `CLOUDFLARE_API_TOKEN` (SECRET, deployment tooling only); this is not an app requirement. Preserve existing mail/DNS records. Cloudflare account/zone access is needed only for the capabilities chosen there.

## 4. Auth email, recovery, order alerts and support

Need one SMTP-capable provider, for example the previously proposed Resend or an existing equivalent, a verified sender domain/address, SMTP host/port/user/password, and a real owner/support recipient mailbox. Put SMTP credentials in Supabase's Auth SMTP configuration (or the self-hosted Auth environment); no current Monechai SMTP environment variables exist.

The official [Supabase custom SMTP instructions](https://supabase.com/docs/guides/auth/auth-smtp) cover these values; the default sender is intended for non-production use. App recovery/MFA code and offline policy tests exist; configure the six-digit recovery-code template per admin-bootstrap.md and verify real email/enrollment/session behavior.

If direct order-alert email is chosen, the current implementation uses provider-neutral `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `EMAIL_FROM`, `ORDER_ALERT_EMAIL` and `ORDER_WORKER_SECRET` rather than a Resend API integration. SMTP credentials/token are secret; see OWNER_SETUP_CHECKLIST.md. Checkout currently has no customer email field; agree on the actual confirmation channel (manual WhatsApp/call or an implemented notification adapter) rather than implying SMTP provides customer receipts automatically.

## 5. Bot protection

Durable application rate limits are implemented. Turnstile is the proposed additional provider and is not integrated yet. If retained, need a widget configured for the store hostname, `NEXT_PUBLIC_TURNSTILE_SITE_KEY` (PUBLIC) and `TURNSTILE_SECRET_KEY` (SECRET server value). Obtain from Cloudflare Dashboard → Turnstile. The app must implement and test server-side token checks; see [official setup](https://developers.cloudflare.com/turnstile/get-started/).

## 6. Independent backup destination

Need a private backup destination independent of the app's VPS/backend, a retention plan and owner-approved recovery/data-loss targets. R2/S3-compatible storage is one option; an existing suitable independent target can be used instead.

If R2 is selected, obtain a bucket, account endpoint and bucket-scoped access key ID/secret from Cloudflare R2 token management. See [official R2 credentials](https://developers.cloudflare.com/r2/api/tokens/). Proposed backup-job names: `R2_ENDPOINT`, `R2_ACCESS_KEY_ID`, `R2_SECRET_ACCESS_KEY`, `BACKUP_BUCKET`, `BACKUP_ENCRYPTION_PASSWORD`. Credential/encryption values are SECRET, stored in the backup job; these are not supported app variables yet. Encrypted app-schema/photo export/isolated restore and unenabled scheduler/failure-alert code now exist; chosen off-site upload, full Supabase service recovery and actual schedule/recipient delivery still need setup/testing.

## 7. Monitoring and error alerts

Need an owner-controlled external uptime monitor and verified alert recipient; UptimeRobot was proposed, an equivalent can be selected. Dashboard access suffices; an API key is only needed for automation. Need a server-error collection/alert mechanism as well: Sentry was proposed, or an adequately implemented logs/alerts alternative.

If using Sentry, obtain project access and its DSN. Proposed names `SENTRY_DSN` / `NEXT_PUBLIC_SENTRY_DSN` identify the reporting endpoint, and `SENTRY_AUTH_TOKEN` is a SECRET build/CI token if source-map/release upload is used. No Sentry SDK is required/installed; existing body-free app events plus operator SMTP failure hooks need chosen host/external monitoring and redaction/incident delivery acceptance. See [Sentry authentication](https://docs.sentry.io/api/auth/). Test incident delivery and PII/token redaction are still required.

## 8. GitHub / CI / release access — fresh check

Read-only checks on 2026-10-11 found:

- Current `gh api user` identity: **Sami-754**.
- `contactshawonhasan-oss/Monechai-website`: **PUBLIC**; current identity has **READ/pull only**, not push/admin permission.
- This differs from the older private-repository checkpoint. The checks did not establish when/why visibility changed; no visibility, collaborator or remote-source change was performed.

Need owner-authorized write access to the correct repo to publish reviewed changes; settings/Actions/environment authorization is needed for CI/deployment secrets and any intended privacy correction. Existing authorized `gh` login may be switched by the owner or the current user can be granted suitable repository access. Do not create/collect a new broad token unnecessarily. Repository authorization is not an application environment variable.

## 9. Courier / COD fulfillment and business information

Need the selected Bangladesh courier's merchant/pickup workflow, approved delivery charges/coverage/ETA, tracking method and COD settlement/failed-delivery/returns process. Manual portal dispatch and manual tracking entry can be used without a courier API. API credentials are needed only if automated courier integration is selected, with provider-specific names agreed then.

Owner inputs also required: real new-product photos/SKUs/prices/stock, brand/contact/WhatsApp/support details, EN/BN product copy, shipping/returns/refund/warranty/privacy/terms content and the chosen notification workflow. These are business configuration/assets, not API secrets. A basic WhatsApp contact link needs the verified number, not a WhatsApp Business API token. COD requires no online payment merchant keys; real bKash/Nagad/card integration would be a separate scoped task.

## How to provide access

Set public values and secrets in an ignored local environment file or the selected provider's environment/secret manager; confirm the variable names are configured without posting secret values. Use owner-approved dashboard sessions, collaborator grants and SSH authorization as appropriate. Never commit secrets or send account passwords/private keys in chat. No new MCP server is required.

**Next setup dependency:** choose/provide one usable backend and authorized owner setup; confirm domain/DNS and intended host. GitHub authorization/privacy also needs owner verification. A09 local pricing validation is complete. Independent local code/checks are complete; owner will supply setup/access afterward. See [store operating plan](STORE_OPERATING_PLAN.md) and [provider-gated online payment goal](goals/goal_11_online_payments.md).
