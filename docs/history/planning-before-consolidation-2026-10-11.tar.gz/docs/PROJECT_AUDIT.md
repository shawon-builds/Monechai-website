# Monechai project audit — 2026-10-10

## Assessment

**Current checkpoint, 2026-10-11: independent code and local checks completed.** Sixteen findings have validated local fixes, A15 is closed by new-product-only scope, and four remain partial/external/upstream (A16/A17/A18/A21). EN/BN routing/metadata/branding, policy revision/consent, owner recovery/MFA, restricted Storage writes, SMTP outbox and CI/operations code now exist. Latest pinnedNode22 checks: strict50/50 zero skips; production browser4/4 including tested WCAG/guest privacy/price/recovery flows; build/Docker/nginx/local app-data+photo restore pass. Production dependency audit0; full tooling audit5 high entries remain for the unpatched braces chain despite a reviewed string-pattern mitigation. Real owner backend/mail/business/host/off-site/full-service recovery is unverified; the store is not ready for real orders.

**Owner confirmed: only Sami will sell products.** Reselling products you source yourself fits the current single-owner architecture. Seller registration/dashboards, multi-seller tenancy, commissions and payouts are unnecessary for this scope and should not be added. Owner subsequently confirmed on 2026-10-11 that stock is **new products only**. The earlier mixed-stock reply was immediately corrected; used/refurbished fields are outside scope.

The audit covered tracked application routes/components, catalog/admin/cart/checkout logic, SQL schema and migrations, configuration, scripts, tests, deployment artifacts and current operational docs. Tests and probes used a disposable local PostgreSQL 17.10 database. No production database, live Supabase Auth/Storage, deployed website, GitHub mutation or real customer order was used. This is a bounded source/local-runtime audit, not a claim that all possible defects have been found.

Latest owner authorization 2026-10-11: finish independent code/local checks now, then supply one access/business setup checklist. Independent work validated; no active goal, waiting for owner setup and upstream-compatible tooling remediation. Existing products preserved. New payment/privacy scope: [STORE_OPERATING_PLAN.md](STORE_OPERATING_PLAN.md); goal 11 is provider-gated. Earlier pause entries below are historical.

## Fix status and implementation log

Owner authorized fixing all code bugs and logging each change on 2026-10-11, then asked to log the remaining work and continue tomorrow. **Latest product scope: new products only** (the earlier mixed-stock reply was immediately corrected). Only the owner sells; delivery is across Bangladesh and the domain is already purchased. This section is the current resolution record. The 2026-10-10 open-findings table was removed; the audit-day record below keeps what was measured and cleaned up. FIXED_LOCAL means a regression/check passed locally, not that the live service is accepted. PARTIAL_VALIDATION means code is saved with final checks outstanding; PARTIAL means some parts are fixed and others remain. Live provider verification stays BLOCKED_EXTERNAL; business details are never invented.

Execution order: goal 08 security/reliability → goal 04 cart/checkout → goal 07 stock/order operations → goal 06 media/catalog → goal 03 advertised prices → remaining goal 08 locale/policies/accessibility → goal 09 regressions → goal 10 dependency/CI/operations code. Each milestone is validated and logged before changing the active goal. The existing user cleanup remains in the working tree and will be preserved.

| Finding | State | Resolution / remaining work |
|---|---|---|
| A01 | FIXED_LOCAL | Migration 0006 enables all-table RLS/revokes API grants; granted non-owner role denial regression passes. Live project deployment still external. |
| A02 | FIXED_LOCAL | Guarded upload/order/primary/remove UI, real image decode/re-encode, authenticated Storage adapter/policy and owner publish lifecycle implemented; local tests pass, live provider still required. |
| A03 | FIXED_LOCAL | 0008 reservation snapshots and row-locked atomic cancellation release/history; concurrent cancellation regression restores stock exactly once. Legacy unknown reservations require review. |
| A04 | FIXED_LOCAL | HttpOnly server-issued recovery cookie and serialized lookup; dropped-commit/reload browser test retains exactly one order. No customer PII persisted. |
| A05 | FIXED_LOCAL | Failed delivery/return transitions, explicit sellable-return restock and audited physical full-COD refund recording implemented and tested; no automatic money transfer. |
| A06 | FIXED_LOCAL | Validated writes enforce 20/item, 30 lines, 100 total; invalid edits preserve previous cart and malformed saved lines are recovered. |
| A07 | FIXED_LOCAL | Add reports actual limits, repeated Added button disabled, safe memory fallback/clear; saved order navigation independent of storage. |
| A08 | FIXED_LOCAL | 0007 approved delivery-area→zone mapping; client-selected shippingZone rejected; admin mapping forms added. Nationwide scope supported; real area/rate inputs external. |
| A09 | FIXED_LOCAL | Actual available-variant min/max prices, price sorting, "From" labels, compare-at suppression and SKU/detail output implemented. Stale checkout quotes require a refreshed total and another confirmation. Validated 2026-10-11: focused 8/8, full 39/39 zero skips, price-review E2E 1/1, checkout/recovery E2E 2/2, lint/typecheck/build/no-drift/diff-check pass on disposable local DB. |
| A10 | FIXED_LOCAL | Published products require owned verified primary bytes (SHA-256/current object) and active variants. Primary deletion and last-variant deactivation unpublish safely. |
| A11 | FIXED_LOCAL | Atomic expiring PostgreSQL counters isolate visitors/IPs across workers; separate recovery budget; trusted IP deployment still must be verified. |
| A12 | FIXED_LOCAL | Preview/catalog durable request budgets, 8 KiB cap and 5-second read deadline; slow-body regression passes. |
| A13 | FIXED_LOCAL | Settings/area/zone reads use shared locks, allowing unrelated checkouts while config updates serialize safely. |
| A14 | FIXED_LOCAL | Safe public-settings fallback, root global error/retry and DB connection/statement/lock deadlines; DB-outage login HTTP 200 verified. |
| A15 | CLOSED_SCOPE | Owner corrected stock to NEW ONLY. NewCondition is accurate; used/refurbished fields are outside scope. Supplier/cost tracking is optional future business tooling. |
| A16 | PARTIAL | Item receipt and admin courier/reference fields implemented and locally checked. Versioned policy forms/pages and mandatory recorded consent implemented/tested; approved serviceability/ETA/contact details and a verified owner/customer notification workflow remain. Transactional leased SMTP outbox/owner queue/retry and scheduler code pass locally; actual SMTP/inbox/customer contact approval remains external. |
| A17 | PARTIAL | Added cart/storage, permission denial, durable recovery, cancellation/returns, real image decoding, media lifecycle and modeled Storage-policy regressions. Real owner login→upload→publish→storefront and customer→admin/revocation journeys still require the actual Supabase project; pricing browser coverage passed under A09; full owner/provider acceptance remains. |
| A18 | PARTIAL_UPSTREAM | Targeted esbuild override removed4 moderate advisories; production audit0. Full audit5 high entries all trace to unpatched braces3.0.3. Checksum/version/layout-guarded string nesting mitigation and hostile-pattern test pass; npm version advisory/CI security gate stays open. ESLint10 upgrade is also blocked by current React-plugin peer compatibility. No forced downgrade or disabled checks. |
| A19 | FIXED_LOCAL | Bangla phone digits now normalize and checkout errors/price labels have EN/BN text. EN/BN route segments, localized links/metadata/alternates/sitemap, optional variant labels and language-navigation/prefetch fixes pass production browser checks. Actual owner catalog translations/domain remain external. |
| A20 | FIXED_LOCAL | Removed nested admin main landmarks; added product filters/stock overview, key/value attributes, safe repeated URL parameters and checkout field errors/focus. Configured name propagated and EN/BN mobile/desktop widths/screenshots/dialog focus verified. WCAG2A/AA/2.1A/AA scans of tested public/cart/login/recovery screens passed; actual owner/photo/admin review remains external. |
| A21 | PARTIAL | CI YAML/strict zero-skip runner, Node22.23.3 pin, preflight/health, encrypted app export/isolated restore and unenabled scheduler/SMTP hooks implemented/checked. Docker/nonroot/static/health and dummy-cert nginx syntax pass. Actual GitHub run/host/DNS/mail/independent upload/full-backend restore/alerts remain external. Fresh GitHub check: current CLI user has READ-only access and target repo reports PUBLIC; owner access/intended visibility needs verification. |

### Historical pause checkpoint (superseded by the current assessment/table)

**Paused on 2026-10-11 for the owner's requested break. Resume on the next requested session; nothing is scheduled or running automatically.** All fixes and the 17-file cleanup remain saved in the local working tree on `main` at `d18cb13`. They are uncommitted and have not been pushed or deployed. The resolution table above is the current work list. The 2026-10-10 open-findings table was removed because it still described repaired defects as open.

The disposable `monechai-fixes-db` container was stopped for the break, with local test data/migrations retained. No app/test server is running. Restart/readiness instructions and the dummy test URL are in `STATS.MD`; unrelated Docker services were untouched.

**Access clarification, 2026-10-11:** owner asked why work proceeded without Supabase credentials. Local fixes used a real disposable PostgreSQL database and fixtures; image/Auth policy coverage used local adapters/modeled identities. No owner Supabase project was connected/accepted. [ACCESS_REQUIRED.md](ACCESS_REQUIRED.md) lists all backend/host/DNS/email/bot/backup/monitoring/GitHub/courier access and remaining integration code. Fresh read-only GitHub checks identify `Sami-754`, with READ-only access to the now PUBLIC target repo; this supersedes the historical private-access checkpoint without establishing when/why it changed. No remote mutation occurred; original implementation pause remains.

1. **A09 done 2026-10-11 under goal 03.** Saved pricing/quote changes in `src/features/catalog/queries.ts`, `src/components/commerce/product.tsx`, the product route, `src/features/checkout/quote.ts`, `domain.ts`, `preview.ts`, `orders.ts`, `checkout-client.tsx` and `src/i18n/dictionary.ts` were validated: focused 8/8, full 39/39 zero skips, price-review E2E 1/1, checkout/recovery E2E 2/2, lint/typecheck/build/postbuild/no-drift/diff-check pass.
2. **Complete A19 and the remaining A20 work under goal 08.** Add/test crawlable EN/BN routes and accurate locale metadata/alternates; propagate the configured store name. Review public variant labels, mobile layout, keyboard/focus and remaining translated text. Owner catalog copy must be supplied rather than invented.
3. **Complete A16 under goals 07/08.** Add configurable public shipping/returns/privacy/terms and the required policy acceptance flow. Obtain actual delivery coverage, fees, ETA, returns/refund rules, courier/support information and the owner notification route. Existing receipt/tracking fields do not complete these requirements. No real notification has been sent.
4. **Close A18 under goal 10.** Review the nine recorded development-tool advisories and update compatible dependencies/overrides; validate migration tooling, lint/typecheck/tests/build afterwards. Avoid the suggested forced core-tool downgrades. Re-run both production and full dependency audits.
5. **Finish A17 and A21 under goals 09/10.** Add CI with disposable PostgreSQL and a mode that fails when required DB tests would skip; pin the supported runtime. Complete actual admin/nonmember/revocation/media/order browser journeys, real-image accessibility/visual checks and the chosen deployment's executable preflight/backup/restore/alerts workflow. Keep live provider acceptance separate from local adapters and modeled SQL identities.
6. **Complete the external launch gates.** Choose and verify the cheapest viable hosting/backend plan; configure owner Supabase Auth/Storage, approved products/photos/rates/policies, domain/TLS/proxy, recovery SMTP, monitoring and independent database-plus-photo backups. Perform the restore drill and full live customer→owner flow. See [production services and exact credential locations](PRODUCTION_SERVICES.md), [database permissions](database-security.md) and [image setup](product-images.md). No account purchase or deployment is part of this pause checkpoint.

At that earlier pause, the remaining six audit IDs were **A16, A17, A18, A19, A20 and A21**. The current unresolved IDs are A16/A17/A18/A21. Live checks also remain for several FIXED_LOCAL findings; they are required before launch even though the code regression is repaired.

### Validation at this pause

| Saved milestone | Checks actually completed | What is still unverified |
|---|---|---|
| Security, cart/checkout, stock/returns, media/catalog | Most recent complete milestone: **39/39 unit/integration tests, 0 skips**, lint, typecheck, build/postbuild, schema no-drift and diff check passed; **2/2 Chromium browser cases** passed. Migrations 0000–0010 applied to the disposable local PostgreSQL database. Earlier failures and successful reruns are recorded below. | Actual Supabase project roles, Auth sessions, Storage and authenticated owner UI acceptance. |
| Latest pricing/quote work | Focused 8/8 incl. final sorting/out-of-stock assertions, full 39/39 zero skips, price-review E2E 1/1, checkout/recovery E2E 2/2, lint/typecheck/build/postbuild/no-drift/diff-check pass. | A09 live storefront/provider acceptance. Prior results now validate this snapshot. |
| Dependency security | Last recorded production audit: **0 advisories**; full audit: **9 development advisories (4 moderate, 5 high)**. | A18 remediation and fresh post-remediation audits. |
| Pause handoff | Audit/goal/status/resume files synchronized. Local links and all required goal sections checked across 14 docs; zero active goals; all 21 audit states/counts correct; git diff --check passed. Disposable DB confirmed stopped, data retained. No implementation tests started for this documentation-only pause. | Tomorrow's validation and implementation work above. |

### Implementation log

- 2026-10-11 latest independent-code handoff: STORE_OPERATING_PLAN/OWNER_SETUP_CHECKLIST/OPERATIONS_CHECKS persisted. Versioned policies/consent and EN/BN routes/metadata/brand passed; root locale and prefetch-cookie races fixed. Owner email-code recovery and mandatory AAL2 plus restrictive direct-Storage policies (even against legacy allow-all) locally verified. Transactional owner-alert queue/fenced worker/retries and safe TLS SMTP adapter added; no real email. Strict CI/runtime, checks and encrypted app DB/photo restore (16 tables/1 actual decoded fixture photo) pass. Latest sequential50/50+production4/4, lint/typecheck/build/postbuild/no-drift, Docker UID1001/HTTP health/assets/pages and dummy-cert nginx syntax pass. Production audit0; full5 high upstream entries retained. Full Supabase/hosting/off-site/merchant acceptance remains external. Prior fixture-overlap orchestration corrected to serial final gates.

- 2026-10-11: Read project authorities and audit; initialized resolution tracker and sequential goal ownership. No bugs marked fixed from code alone. Owner's final correction is new products only.
- 2026-10-11 pause: owner asked to log all fixes/remaining work for tomorrow. Saved the unfinished pricing slice without claiming final validation; synchronized STATS.MD, MIGRATION_STATUS.md and the goal records. All work is local/uncommitted; there is no automatic continuation.
- 2026-10-11 handoff completion: documentation links/goal sections/status counts across 14 files and git diff --check passed. Test database stopped with data retained and no app/test server running. Exact next task is goal 03 pricing final validation after the owner resumes.
- 2026-10-11 access clarification: added ACCESS_REQUIRED.md and synchronized service/status/index/auth/deployment goal records. Sixteen-doc link/section/access-group checks and git diff --check passed. Actual provider setup remains unverified; latest GitHub access/visibility corrected from fresh read-only API results. No app changes/tests or external setup/mutations; implementation pause remains.
- 2026-10-11 documentation cleanup: removed the superseded open-findings table, duplicate credential list and original fix order from this file. Updated README, architecture, deployment, database security, admin bootstrap, testing and the goal 03/05/08/10 current statements that still described removed prototype files or unfinished image upload as current work. No app tests rerun.

## Audit-day record (2026-10-10)

This section records what the audit measured and removed. It is not the current defect list. Current status is the resolution table above.

Before the 2026-10-11 fixes, local probes on a disposable database showed: a granted API role could read a dummy order and mark its payment paid; publishing accepted an invalid photo key and a product with no active variants; cancelling an order left stock at zero; a dropped checkout response plus reload created a second order; a cart whose quantities summed past 100 disappeared on reload. Those probes used rolled-back fixtures. The resolution table records which of them now have local regressions.

### Cleanup performed

Removed 17 obsolete files: `index.html`, `shop.html`, `checkout.html`, `order-success.html`, the legacy stylesheet and three scripts, three old PNG logos and three duplicated SVGs under `assets/`, `public/logo.png`, `public/logo-full.png`, and the unused `src/features/checkout/payment-boundary.ts`. Active SVG branding, application modules, SQL migrations, tests, Docker/proxy artifacts, goal files and operational docs stayed. The demo seed's 24 products and nine categories moved to `fixtures/demo-catalog.json` before `products.js` was deleted; the seed parses JSON. The old design is in Git history at the audit-start commit. Orphan CSS for unused `.gold`, footer `strong` and brand `strong`/`small` selectors was removed after checking active markup.

Production `npm start` had been returning 404 for logo, CSS and JavaScript. `scripts/prepare-standalone.mjs` now runs from `postbuild` and copies `public` and `.next/static` into the standalone artifact. After rebuild, those probes and health returned 200. Legacy `.html` URLs return 308. The root `data-scroll-behavior="smooth"` attribute was added after the browser test reported the Next navigation warning.

### Checks run that day

- `npm ci`, migrations 0000–0005, lint, typecheck and build passed. `npm test`: 28 passed, 0 skipped. Production `npm audit --omit=dev`: 0 findings. Full audit: 9 development advisories (4 moderate, 5 high).
- JSON seed twice: 9 categories, 24 products, 24 variants, 24 image rows, 0 published.
- Chromium end-to-end passed 1/1 after installing the matching browser (390/800/1280, English/Bangla, keyboard cart, tampered, invalid, out-of-stock, persisted COD).
- Standalone health, logo, CSS and JavaScript returned 200. `git diff --check`, local Markdown links, required goal sections and a common secret-signature scan passed. At that moment goal 10 was the active goal. The later pause set zero active goals.
- Docker build, nginx TLS validation, live Supabase Auth/Storage, a full visual baseline, live deployment and a restore drill were not run. Temporary audit scripts, the audit database container and generated reports were removed afterward.

Live credentials and provider setup are listed in [ACCESS_REQUIRED.md](ACCESS_REQUIRED.md). COD needs no payment-merchant credentials.

## Fix log

### 2026-10-11 — Goal 08 security/reliability slice

- A01: all twelve current app tables use Drizzle RLS. Migration 0006 revokes PUBLIC/anon/authenticated/service_role privileges. Granted non-owner permission regression verifies denied reads/mutations even after accidental grants. Live provider application is pending owner access.
- A11/A12: PostgreSQL atomic, expiring hashed counters replace the process Map/shared unidentified bucket; visitor cookie isolates fallback customers and proxy IP trust is explicit. Preview and catalog now have budgets. Body stream has a deadline and responds 408 on timeout. Checkout retry recovery will be refined under 04.
- A14: cached per-request settings read fails to an honest contact-free shell, global root error has independent bilingual recovery, and Next error handler now uses documented retry(). DB client has connect/statement/lock timeouts. Built login with unavailable DB returned HTTP 200.
- Validation: first full run had 30/31 tests pass; one counter test exposed Date serialization in raw SQL. Changed bound timestamps to ISO strings, six focused regressions passed, then full 31/31 passed with zero skips. Lint/typecheck/build and Drizzle no-drift passed. Browser gate subsequently passed 1/1; proceeding to goal 04.

### 2026-10-11 — Goal 04 checkout/cart slice

- Added private HttpOnly checkout recovery cookie and status/ack endpoint, using the same DB advisory key as order placement. Cookie is retained until the browser receives and acknowledges the saved reference. Fields freeze during submission; no PII is stored in local/session storage. Lost response followed by recovery outage and reload now recovers exactly one order.
- Cart writes validate total/line limits, salvage valid corrupted lines and fall back to tab memory; add feedback reflects actual changes. Successful order navigation cannot throw on browser storage failure. Bangla phone digits normalize correctly; field errors are associated and focus the invalid field.
- 0007 delivery areas assign server-owned fee zones, with protected admin configuration and immutable order area snapshots. Browser-supplied zone/price flags remain rejected. Owner confirms delivery across Bangladesh; actual coverage/rates are not seeded/guessed. Exclusive singleton settings/zone locks changed to shared locks.
- Validation: full 34/34 tests passed before final area assertions; focused 10/10 then passed with final area assertions. Initial browser run 1/2 failed from the new two-element error selector; fixed selector, rerun 2/2 passed including lost-response recovery. One focused run overlapped E2E fixtures and failed 9/10; rerun in isolation passed 10/10. Lint/typecheck/build/diff/no-drift passed. Live admin settings/provider verification still external.

### 2026-10-11 — Goal 07 inventory/order slice

- 0008 records whether a new order item reserved stock; cancellation restores all reserved quantities and logs movements in one locked transaction, exactly once. Unknown legacy reservations are explicitly rejected for review instead of guessed. Full purchase item snapshots have a DB immutability trigger.
- Added delivery_failed, return_requested and returned transitions. Returned inventory is restored only after explicit admin confirmation that all items are received and sellable as new. COD not collected is recorded as failed; actual full refunds of previously paid returned orders are manually confirmed/audited, never pretend gateway payouts.
- Admin can store courier/reference and view inventory/payment history. Private customer success page includes item receipt and courier reference without name/phone/address exposure. Policy content/configuration remains for the next 08 slice.
- Validation: 5/5 focused stock/order tests incl. two concurrent cancellations; full 36/36 tests zero skips, lint/typecheck/build/diff/no-drift, E2E 2/2 passed. First snapshot assertion needed Drizzle cause inspection, and checkout DB parameter type needed transaction-compatible narrowing; both fixed/rerun. Live owner admin/browser verification remains external.

### 2026-10-11 — Goal 06 media/catalog slice

- Real JPEG/PNG/WebP input signatures, 5 MiB/16M-pixel bounds, animation rejection and stripped WebP normalization. Generated owned random keys, verified timestamp/content hash, current object-byte checks before publish, ten-photo limit, ordering/primary/removal controls and safe orphan cleanup events.
- Normal Storage actions use signed-in admin JWT; no privileged Storage key needed. Reviewed SQL policy artifact restricts upload to whitelisted existing users and real-product namespace; anonymous/nonmember writes denied and membership revocation enforced. Auth cookies explicitly HttpOnly and Secure in production, provider fetch bounded/no-store. Live bucket/project configuration still not verified.
- Replaced manual attribute JSON with key/value rows, blocked prototype/duplicate keys, added admin SKU/name/status/category filters and stock summary. Removed nested admin main landmarks. Inventory-tracking mode cannot change while unfulfilled orders reserve that variant; stock/price history preserved.
- 0009/0010 media columns applied locally; Sharp 0.35.5 explicit dependency. Five focused decoder/owner-lifecycle/SQL-policy tests passed; full 39/39 zero skips, lint/typecheck/build/diff/no-drift, E2E2/2 passed. Media adapter uses real sample pixels + local object store; Storage identity policies modeled in SQL, not a live Auth/bucket session. Product owner browser journey on actual provider remains external.

### 2026-10-11 — Goal 03 pricing slice, saved with final validation pending

- A09: cards and database price sorting now resolve the minimum price among available active variants, with maximum price for a truthful "From" display. If all active variants are unavailable, their prices remain visible with unavailable state. Detail data retains the base price solely for variants that inherit it. Unsupported compare-at discounts are suppressed when variant prices differ; SKU is included in public detail data and structured data consumes the effective price.
- Small goal 04 dependency: preview emits a fingerprint of server-derived item quantities/prices, delivery area and totals. Submit re-derives current values and rejects stale totals with PRICE_CHANGED before creating an order. Checkout refreshes the summary and requires another click after review; browser totals remain non-authoritative. The existing same-key order recovery happens first. Fixture inputs were updated for the required quote hash.
- Validated 2026-10-11 after owner resume: focused 8/8, full 39/39 zero skips, price-review E2E 1/1, checkout/recovery E2E 2/2, lint/typecheck/build/postbuild/no-drift/diff-check pass. A09 is FIXED_LOCAL.
- Owner requested pause and tomorrow's continuation before this milestone's final gates. No further implementation or new app tests were started for the handoff.
