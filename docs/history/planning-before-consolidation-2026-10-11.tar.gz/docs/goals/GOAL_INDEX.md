# Monechi rebuild — goal index

## Project objective

Replace the static Monechai prototype with one maintainable Next.js modular monolith backed by PostgreSQL: an owner can create and publish products with images in `/admin`, and a customer can place a real, server-priced, inventory-safe COD order that the owner can manage. Preserve the useful brand identity (now warm white, charcoal and restrained champagne gold at the owner's request) and English/Bangla experience. Deploy on a normal Node.js VPS with managed PostgreSQL; Vercel is optional.

Owner confirmed 2026-10-10: **only Sami sells products**. This is a single-owner resale store; marketplace seller accounts, commissions and payouts are out of scope. Owner corrected product scope on 2026-10-11: **new products only**; used/refurbished features are out of scope.

Owner update 2026-10-11: **domain purchased; complete production readiness required; minimize recurring cost and research free hosting first.** [Production services/tools and hosting research](../PRODUCTION_SERVICES.md) records candidates, actual limitations, access needs and launch acceptance gates. A self-hosted backend is only a researched option until selected and validated; current managed deployment instructions remain the implementation baseline. No domain/server purchase or provider setup was performed in this research.

## Repository audit and execution order

At the start of the original migration, the checkout had no git commits and contained four HTML pages, one stylesheet, three scripts, and logos. `assets/js/products.js` contained 24 products and nine categories; all imagery is external Unsplash placeholder imagery. `app.js` kept cart, wishlist and last order in localStorage, computed checkout totals in the browser, and redirected to a success page without a database. Search and sort loaded the full catalog in the browser. The old HTML duplicated chrome, included fake payment selectors, a midnight-reset sale timer, unsupported reviews/sold counts and business claims, and inconsistent/path-stale documentation. On 2026-10-10 the owner requested removal of the obsolete runtime; it was removed after seed data was preserved as JSON. Retrieve the old design from Git history. See [current audit](../PROJECT_AUDIT.md).

| Goal | Status | Blocked state | Depends on | Description | External access |
|---|---|---|---|---|---|
| [01 Foundation](goal_01_foundation.md) | DONE | Local foundation verified; separate live backend now provisioned, final acceptance later | — | Scaffold Next.js, TypeScript, base design, PostgreSQL/Drizzle wiring, environment checks and quality scripts. | Production `DATABASE_URL` later; local PostgreSQL verified. |
| [02 Catalog](goal_02_catalog.md) | DONE | Local migration/seed/tests verified; live production catalog needs owner access and verified assets | 01 | Model products, categories, variants and images; safely import prototype data and query it. | PostgreSQL/Supabase project for live migration. |
| [03 Storefront](goal_03_storefront.md) | DONE | Local pricing/quote validation passed 2026-10-11; live provider acceptance external | 02 | Responsive database-backed storefront and accurate purchasable prices. | None for pricing validation. |
| [04 Cart and checkout](goal_04_cart_checkout.md) | DONE | Quote/PRICE_CHANGED dependency validated 2026-10-11; live rates/config later | 02, 03 | Guest cart and transactional server-authoritative COD checkout. | Local test PostgreSQL; owner live rates/config later. |
| [05 Admin auth](goal_05_admin_auth.md) | BLOCKED | Live schema/ACL/initial Auth setup applied; user paused for friend login, designated owner email/MFA/SMTP/session acceptance pending | 01 | Add Supabase Auth, explicit admin whitelist, protected routes and first-admin bootstrap. | Supabase URL/publishable key and an owner-created first user. |
| [06 Admin catalog](goal_06_admin_catalog.md) | BLOCKED | Media/catalog code and local tests passed; live products bucket/policies configured; real owner login/photo/publish acceptance awaits identity/MFA | 02, 05 | Product/category CRUD, variants, stock and image management. | Owner Supabase Auth/Storage project and real photos. |
| [07 Order management](goal_07_order_management.md) | BLOCKED | Local migrations/tests/UI implemented; authenticated customer→admin browser verification waits for owner Supabase access | 04, 05 | Build admin order list/detail, safe status changes and business settings. | Live DB/admin user for end-to-end verification. |
| [08 i18n, SEO and security](goal_08_i18n_seo_security.md) | BLOCKED | Locale/brand/privacy/policy code passes locally; approved business copy and live security/owner acceptance external | 03, 04, 06, 07 | English/Bangla, SEO, security/abuse controls and truthful business information. | Approved policies/contact, canonical domain/DNS and live security checks. |
| [09 Testing and visual regression](goal_09_testing.md) | BLOCKED | Local50-test suite and production4-case/WCAG/locale/price/privacy checks pass; actual owner/backend/photo acceptance remains | 03, 04, 06, 07, 08 | Automated regressions and desktop/tablet/mobile verification. | Local DB/browser tools available; actual Auth/Storage for owner journeys. |
| [10 Deployment hardening](goal_10_deployment_hardening.md) | BLOCKED | Independent artifacts/tests/Docker/nginx/ops pass; unpatched tooling/version gate and actual host/provider/off-site acceptance remain | 01–09 for final completion; independent Docker/docs slice unblocked | Finalize Docker/VPS deployment, docs, backup guidance, legacy cleanup and final quality gates. | VPS/Cloudflare/DNS access only for actual deployment. |
| [11 Online payments](goal_11_online_payments.md) | BLOCKED | Provider/launch choice and merchant sandbox access needed | 04, 05, 07, 08, 09 | Real guest-compatible gateway with verified payment and inventory lifecycle. | Selected provider merchant/sandbox/production access. |

**State key:** BLOCKED means required owner/provider/production acceptance or upstream tooling remediation remains. DONE describes a completed local milestone; overall production acceptance remains mandatory. Historical PAUSED entries remain in work logs only.

**Current active goal:** None — user paused live setup2026-10-11 to log into friend's account and continue later. Goal05 is BLOCKED on designated owner email/identity, personal MFA and custom SMTP/code-template/actual session acceptance. Live Monechai project `lmrdvenrchsnueztzcdi` in organization `lpbdravwzduphzmfnlsj` has13 migrations/16 RLS tables, scoped runtime role, protected products bucket and initial Auth configuration. Old needed Lead project `syzifxmdbfsfistwapkq` remains untouched.

**Next action:** Wait for user account switch and explicit resume; verify the friend can access this exact Supabase project, then follow [Supabase setup handoff](../SUPABASE_SETUP_HANDOFF.md). Owner email is unknown and will be added later. Remaining business/host/domain/mail/backup/payment inputs are in [owner checklist](../OWNER_SETUP_CHECKLIST.md). No automatic continuation during the pause.

**Current fix record:** [Audit resolution and latest evidence](../PROJECT_AUDIT.md). Sixteen findings FIXED_LOCAL, A15 CLOSED_SCOPE, four partial/external/upstream IDs:A16/A17/A18/A21. No source commit, push, real email or deployment in this local work.

**New milestone:** [11 Online payments](goal_11_online_payments.md) is BLOCKED on owner gateway/merchant selection. Guest checkout and bearer receipt limitations are recorded in [store operating plan](../STORE_OPERATING_PLAN.md). OTP is required only before future sensitive customer lookup/edits/history; no compulsory buyer accounts. Goal 10 final completion includes 11 if online payments are retained for launch.

**Current access inventory:** [Exact backend/provider/credential checklist](../ACCESS_REQUIRED.md). Live Supabase initial setup applied, actual owner Auth/Storage acceptance pending; Recovery/MFA, policy/consent, SMTP outbox and operations code exist; real account/configuration/delivery/full-backend/off-site acceptance remains. Turnstile is optional provider-gated scope. Fresh GitHub API checks report current CLI user `Sami-754`, target repo PUBLIC with READ only; owner must verify intended visibility/authorize write/settings access before CI/release. No remote mutation. Independent local work is completed; external setup stays pending.

## Master Prompt Coverage

2026-10-10 execution update: goal 10 owns the completed repository audit/cleanup (`docs/PROJECT_AUDIT.md`); follow-up fixes retain their goal owners. No migration goal closes from build/tests alone. Legacy removal is complete with reference preserved in Git. 2026-10-11 resume: goal 03 validation passed; 08/05/07/09/10 independent code verified; real-owner and upstream gates remain. Latest scope is in [store operating plan](../STORE_OPERATING_PLAN.md).

- Full repository audit, recent history, safe git handling and legacy comparison → 01; final legacy cleanup → 10.
- Modular monolith, Next.js App Router/React/TypeScript, Server Components, code boundaries, portable Node/VPS architecture, environment validation, health/logging base and quality scripts → 01.
- PostgreSQL/Drizzle migration tooling → 01; catalog schema, constraints/indexes, integer money, variants, images, stock and legacy product seed/import → 02.
- Home blocks, black/gold CSS/logo, responsive layout, reusable commerce components, shop/product routes, database search/filter/sort/pagination, accessibility and performance → 03.
- Guest cart, price/stock refresh, shipping zones/settings/calculation, customer validation, snapshots, transactional order creation, concurrency, idempotency, safe public order token, COD-only payment boundary, success/error states → 04.
- Supabase Auth, explicit `admin_members`, server authorization, secure sessions, admin login and first-admin bootstrap → 05.
- Source-free product/category creation and editing, image storage abstraction/upload/delete/reorder/primary, localized fields, publishing, featured, stock and storefront cache invalidation → 06.
- Admin order list/detail, valid status transitions/history, payment status protection, central business settings and management → 07.
- English/Bangla dictionaries and preference, metadata/canonical/Open Graph/sitemap/robots/Product JSON-LD, headers, XSS/CSRF/input/body/error protections, checkout abuse prevention, PII review, WhatsApp and false-claim cleanup → 08.
- Money/shipping/phone/schema/totals/stock/status domain tests, order persistence/security/idempotency integration tests, Playwright COD/invalid/out-of-stock journeys and desktop/tablet/mobile visual parity → 09.
- Docker, standalone build, Nginx/Caddy and Cloudflare/VPS/Supabase deployment guidance, backup/recovery, README, `ARCHITECTURE.md`, secret scan, removal of active static runtime, final gates and master coverage review → 10.
- Cheapest viable hosting, external service/credential inventory, purchased-domain DNS setup, actual SMTP/monitoring/recovery/CI/operating acceptance → 10; owner Auth recovery/MFA → 05; courier/order notification/reconciliation → 07; abuse controls/policies → 08. See `../PRODUCTION_SERVICES.md`.
- Real online gateway if retained for launch →11, requiring merchant access; optional future coupons/promotions/customer accounts/customer automatic messaging/courier APIs/invoices/analytics → scoped future work, no speculative integration. Owner SMTP alerts are implemented under07; operational alerts/backups under10.

- Latest product/account/privacy/payment Q&A → STORE_OPERATING_PLAN.md; guest/receipt protections → 04/08/09; actual online gateway → 11.

The coverage pass maps every major specification area to an owning goal. The detailed files preserve acceptance criteria and cross-goal boundaries.
