# Goal 03 — Storefront

## Goal

Rebuild the public Monechai experience on server-rendered, reusable Next.js routes.

## Why this exists

The existing design is useful, but duplicated HTML and browser-wide catalog scripts prevent maintainable growth.

## Requirements from the master prompt

- Implement `/`, `/shop`, `/products/[slug]`, and useful redirects from legacy HTML URLs. Use Server Components by default; Client Components only for interactive parts.
- Preserve black/gold identity, existing logo, home sections, category feel, product cards, cart-drawer appearance, simple checkout visual direction, responsive desktop/tablet/mobile layout and WhatsApp affordance.
- Compose homepage from reusable blocks such as Hero, HowToOrder, CategoryGrid, FeaturedProducts, ProductGrid, Promotion, TrustBenefits and Testimonials; blocks receive clean data interfaces and know nothing about PostgreSQL.
- Build useful reusable commerce elements: ProductCard/Grid/Price/Gallery/Badge, search/filter/pagination/quantity UI and shared header/footer. Avoid trivial abstractions.
- Shop URL params support `q`, category, price-asc, price-desc, default/relevance and page; filter/sort/page in PostgreSQL, with hundreds/thousands of products in mind. Do not download the full catalog to the browser.
- Add loading, empty catalog/no-results, missing product, unavailable/out-of-stock and 404 states. Use safe rendering, image optimization, accessible controls/labels/alt/focus/drawer behavior and reasonable performance/caching.
- Do not present false sales, countdowns, reviews, sold counts or delivery claims from the prototype. A promotion block appears only when supported by real configured data.

## Scope

Public home/shop/product pages, shared visual system and components, server query integration, responsive/accessibility baseline.

## Out of scope

Functional cart/checkout (04), admin catalog (06), full i18n/SEO/security pass (08), final visual regression (09).

## Dependencies

02 catalog and 01 base app. The removed prototype's pages and CSS are in Git history when a visual comparison is needed.

## External requirements

None for code. Real store images from Supabase Storage or the owner are needed before publishing production products; prototype Unsplash images remain clearly development-only.

## Files expected to change

`src/app/(store)`, `src/components/blocks`, `src/components/commerce`, `src/components/layout`, `src/styles`, `public`, redirects in `next.config.*`.

## Implementation checklist

- [x] A09: align displayed/sorted prices with purchasable variants (validated 2026-10-11: focused 8/8, full 39/39, E2E 3/3, lint/typecheck/build/no-drift pass).
- [x] Run final sorting/out-of-stock assertions and new price-review browser case, full suite, lint/typecheck and production build before closing this milestone.

- [x] Build shared branded header, navigation, footer and responsive shell.
- [x] Implement reusable homepage blocks with truthful content (omit unverified promotions/testimonials).
- [x] Implement server-rendered `/shop` search/category/sort/page and stateful URL controls.
- [x] Implement product details/gallery and unavailable/404 states (ordering is intentionally disabled until 04).
- [x] Add loading/empty/error states, accessible controls and optimized images where verified Storage is configured; otherwise show local logo placeholder.
- [x] Compare desktop, tablet and mobile with legacy visual baseline (Firefox headless screenshots); Chromium Playwright keyboard navigation checked skip link, header search, shop filters/sort, product link and pagination.
- [x] Run lint/typecheck/tests/build and update docs/status.

## Validation / tests

Server query tests for URL filters and pagination; browse routes at desktop/tablet/mobile widths; keyboard checks; lint/typecheck/build.

## Definition of done

Public routes render DB-backed products with useful parity to the old visual design, scalable server filtering and accessible responsive behavior.

## Work log

2026-10-11 validation (owner resumed): focused catalog/domain/order/inventory 8/8 incl. price-asc sorting, From min/max, compare-at suppression and out-of-stock override; price-review E2E 1/1 (variant display + PRICE_CHANGED second confirmation); checkout/recovery E2E 2/2; full 39/39 zero skips; lint/typecheck/build/postbuild/no-drift/diff-check pass on disposable monechai-fixes-db. A09 FIXED_LOCAL. Status DONE locally; live provider acceptance remains external.

2026-10-11 pause: owner requested logging all fixes/remaining work and continuing tomorrow. Effective available-variant min/max/sorting, From labels, compare-at suppression, base inheritance and detail SKU saved. Small goal 04 dependency adds server-derived quote fingerprints and explicit review after stale totals. Focused 10/10 passed before final catalog assertions; existing checkout/recovery E2E 2/2 passed with quote changes; lint/typecheck passed before latest test additions. Final assertions, new tests/e2e/price-review.spec.ts, full updated suite and build NOT RUN. Status PAUSED; resume final validation here before 08. See PROJECT_AUDIT.md for file list and exact remaining audit IDs.

2026-10-11: Active for A09 effective purchasable variant price/sorting/detail/schema alignment. Keep product base as variant fallback, suppress unsupported compare-at displays for variable prices, and test out-of-stock overrides.

2026-10-10: Reopened as PAUSED after whole-project audit found advertised/sorted product base prices can differ from all active variant prices (A09). Prior local storefront milestone results remain historical evidence, not proof this regression is resolved.

2026-10-06: Started goal. Reviewed legacy homepage/shop (unverified sale, delivery, reviews and social/contact claims removed), catalog visibility policy and Next.js 16.3.8 bundled App Router guides. Server page searchParams/params are promises; uncached ORM reads must occur at request time, not build/prerender time. Demo imagery remains hidden.

2026-10-06: Built shared shell and query-backed routes; categories only show when containing a non-demo published product; cards expose active variant availability. Opt-in public Supabase Storage image keys are constrained to the `products` bucket and configured project host, with a logo placeholder otherwise. No non-functional cart or speculative WhatsApp number presented until checkout/contact details are verified. Redirected index/shop legacy HTML; checkout/success cannot redirect to fake success. Lint/typecheck/build passed; six tests passed with local DB. Built standalone server smoke-tested against local PostgreSQL: empty home/shop 200, filtered shop 200, temporary published product 200, missing product 404 (after moving loading boundary to `/shop`), index/shop HTML redirects 308, legacy checkout 404. Fixture removed afterward. Headless Firefox screenshots at 1280×900, 800×900 and 390×844 confirmed black/gold layout, logo, legible filters and no horizontal overflow in viewed area; screenshots used standalone static/public assets copied as deployment will do. No browser keyboard-interaction tooling used; focus/labels/semantic forms reviewed in code only. Final lint/typecheck/build, six DB-backed tests and Drizzle no-drift check passed. Optional verified public `NEXT_PUBLIC_WHATSAPP_NUMBER` link is hidden until configured.

## Result

**DONE locally 2026-10-11:** A09 validated (see work log). Earlier results below describe the original local milestone.

Public routes remain DB-backed, responsive and truthful; home/shop/product/legacy redirects were validated with local PostgreSQL. Lint/typecheck/build, 6 DB-backed tests and no-drift passed at goal 03 validation. On 2026-10-06, the remaining interactive keyboard check passed in Chromium Playwright against local fixture: skip link → brand → search, keyboard shop category/sort/apply, product link and next-page pagination. Goal 04's checkout E2E test owns that fixture and also exercises COD. No production Supabase credentials or verified product imagery have been provided; demo remains unpublished. Future richer accessibility/visual regression belongs to 09.

## Work log addendum

2026-10-06: User requested goal 04 before the last keyboard check; goal 03 was temporarily paused. After Playwright Chromium became available, its keyboard check passed in `tests/e2e/checkout.spec.ts`; closing 03 now while 04 continues.

2026-10-07: Theme moved to warm white, charcoal and restrained champagne gold in `src/app/globals.css`. The supplied logo went into `public`, with a light footer version, cropped mark and favicon, then header/hero/footer logos were scaled to 0.9×. Lint, typecheck and build passed. The static HTML copies mentioned in the original notes were removed on 2026-10-10. Full visual comparison remains with goal 09. Admin product photos are a separate goal 06 path.
