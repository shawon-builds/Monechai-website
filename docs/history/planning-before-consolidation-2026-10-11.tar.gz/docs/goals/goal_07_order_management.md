# Goal 07 — Orders and business settings

## Goal

Give authorized admins a useful order queue, safe status controls and central store settings.

## Why this exists

Persisted orders must be actionable for the owner, and delivery/contact/payment settings must not live in scattered UI constants.

## Requirements from the master prompt

- Implement `/admin/orders`, `/admin/orders/[id]`, `/admin/settings` and an overview `/admin`. Order list shows number, timestamp, customer, phone, area, total, payment method/status and order status; detail shows item snapshots, quantities, customer/address, shipping, totals, note and status.
- Define explicit statuses (`pending_confirmation`, `confirmed`, `packed`, `shipped`, `delivered`, `cancelled`) and valid transitions; prevent impossible changes and record timestamps/history when reasonably simple. Payment status and method remain separate; browser cannot set paid.
- Add `site_settings` (and `order_status_history` if used), server-only authorized mutations, settings for store name, WhatsApp number, hotline, support email, Inside/Outside Dhaka fees, free threshold, enabled implemented payment methods, address/contact info. Cache and invalidate safely. Only enable real COD now.
- Keep future provider/coupons/notifications/courier/invoice/analytics boundaries simple and documented without implementing speculative features.

## Scope

Admin order list/detail/status updates, status history, settings schema/forms and cache invalidation.

## Out of scope

Online payment gateway, customer accounts, notifications, courier API, invoice/analytics systems.

## Dependencies

04 order persistence and 05 admin auth; 06 may establish admin form conventions.

## External requirements

Real PostgreSQL and authorized admin login for end-to-end verification. Owner-confirmed contact values improve production settings; never invent verified hotline/support claims.

## Files expected to change

`src/db/schema/orders.ts`, `src/db/schema/settings.ts`, migrations, `src/features/orders`, `src/features/admin/settings`, `src/app/admin/orders`, `src/app/admin/settings`.

## Implementation checklist

- [x] Transactional owner-alert outbox, leased/fenced TLS SMTP worker, redacted retries/failed queue and MFA-protected admin retry; local tests pass.
- [ ] Actual SMTP/inbox/scheduler and owner-approved customer confirmation workflow.

- [x] A03: restore reserved stock atomically and once on pre-shipment cancellation; scope failed-delivery/returns handling (A05).

- [x] Define and test allowed order transitions/history (local DB; live Auth verification pending).
- [x] Build paginated/filterable order list and detail (local DB; live UI pending).
- [x] Add server-authorized status updates and payment-status protections (COD payment remains pending; no browser mutation; live Auth pending).
- [x] Add central site/shipping/contact/payment settings and safe invalidation (local tests; live UI/auth pending).
- [ ] Verify a checkout order appears and can be managed by admin (local DB service tests passed; live authenticated browser journey pending).
- [x] Run local gates; update docs/status (live Auth/UI validation remains open).

## Validation / tests

Status transition tests, admin authorization tests, order list/detail/settings integration tests, real customer→admin flow, lint/typecheck/build.

## Definition of done

Every real order is visible to authorized staff with complete snapshots/customer details and only valid status changes; central settings drive commerce/UI values.

## Work log

2026-10-11 notification code verified:0012 RLS/revokes unique transactional outbox, leased/fenced SMTP worker, bounded TLS adapter (no customer PII/receipt token), secret-token endpoint, admin queue/status/failed retry. Focused3/3 and lint/typecheck passed; shared-fixture parallel ad hoc run corrected to serial. At-least-once SMTP can repeat an alert after uncertain acknowledgement but never creates an order. No real SMTP send. Actual mailbox/scheduler/customer contact approval/admin provider acceptance remains blocked;10 final gates active.

2026-10-11: Active independent owner-notification slice after local10 operations checks. Add transactional order-alert outbox and bounded SMTP worker with concurrency/retry tests; actual SMTP/from/recipient and customer contact process remain owner setup. No live message authorization used or actual message sent.

2026-10-11 pause handoff: A03/A05 stock/returns fixes and receipt/courier reference surfaces saved/tested. Actual customer→authorized admin status/payment/return UI acceptance remains BLOCKED on owner Auth/project. A16 policies/ETA/contact/notification work is recorded in audit and goal 08; no business rules or real notifications invented/sent. Owner asked to continue tomorrow.

2026-10-11: Local A03/A05 fixed with 0008 reservation snapshots, exactly-once cancellation history, explicit return restock, failed delivery/return graph and actual cash refund recording. Added receipt/courier fields. Focused5/5 incl. concurrent cancels, full36/36, lint/typecheck/build/no-drift/diff/E2E2/2 pass after wrapped-error/type fixes. Snapshot immutability DB trigger tested. Live Auth/admin acceptance remains BLOCKED; activate 06 for independent media code.

2026-10-11: Active for A03 cancellation restock and A05 failed delivery/returns/refund records, plus receipt/tracking surfaces. Live Auth acceptance remains blocked, but local code/tests proceed. Goal 04 added approved delivery-area settings as a small documented dependency; no actual rates seeded.

2026-10-10 audit: cancelling a last-unit order left stock at zero, and status changes did not adjust inventory. The 2026-10-11 slice above restores reserved stock on cancel and records returns. Live owner verification remains blocked.

- Started at the owner's request while image upload was still unfinished. That upload later landed under goal 06. Goal 05 live verification still needs owner Supabase access. Every Server Action authorizes itself.
- Implemented 0003 migration mapping historical `placed` rows to `pending_confirmation`, adding `packed` and backfilling initial history; new checkout writes history in its transaction. Row-locked transitions, guarded queue/detail/action, exact order-number/status filters, snapshot display. Test runner now serializes integration files sharing fixed shipping-zone keys (initial parallel run raced). Initial test asserted packed→cancelled invalid; corrected to shipped→cancelled.
- Added singleton `site_settings` (0004), guarded settings forms for verified contacts/COD enablement and owner-entered two-zone fees/thresholds (no invented rates). Preview/transactional checkout check COD enablement, existing idempotent retry still returns original order; footer reads only configured contacts when DB available. Added explicit delivered-COD cash-received action with row lock and payment audit table (0005); no browser-supplied payment status or speculative refund/online payment flow. Local PostgreSQL 17 migrations 0000–0005, 20/20 tests, 1/1 checkout Playwright E2E (before final payment change), lint/typecheck/build, Drizzle no-drift and diff check passed. Tests cover queue/history, settings validation/rollback, payment gating and checkout disable/retry. No live Auth/admin browser tests; legacy `NEXT_PUBLIC_WHATSAPP_NUMBER` superseded in active Next shell. Next: authenticated end-to-end order→admin flow when owner provides Supabase access; review deployment/config later.
- Follow-up: contact settings are read at request time through Next `connection()`. Production build, lint, typecheck and diff check passed. The static prototype was removed on 2026-10-10.
- Limitation: old data status backfill has not been tested with actual pre-0003 orders; no real rates/contact values entered. Completed status/setting service tests use local DB without a real authenticated admin browser. No admin-access credentials invented. Marked BLOCKED for live verification, resume goal 06 meanwhile.

## Result

BLOCKED_EXTERNAL. Stock/order/COD/returns/history and transactional leased SMTP owner-alert code pass local tests. Actual owner/admin Auth, mailbox/inbox/scheduler/customer contact workflow and approved delivery configuration require acceptance.
