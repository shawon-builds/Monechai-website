# Goal 10 — Deployment, documentation and final hardening

## Goal

Leave one production-capable application with current documentation and reproducible VPS/Docker deployment.

## Why this exists

The migration is not complete until the owner can deploy, back up and operate the real store without the static prototype.

## Requirements from the master prompt

- Verify production build and use standalone Next output if appropriate. Provide Dockerfile and deployment examples for ordinary Linux/Node VPS behind Nginx or Caddy and Cloudflare, using managed PostgreSQL/Supabase rather than requiring DB on the VPS; Vercel optional.
- Document Supabase Auth/Storage/DB production setup, environment variables, migration generation/application, safe rollback/recovery strategy, development seed, first-admin bootstrap, adding products, managing orders, genuine COD-only payments, tests, build, local/VPS/Docker commands and troubleshooting.
- Add `ARCHITECTURE.md` explaining boundaries, schema, request/checkout/payment/auth/storage flows, deployment, and explicit invariants: client price/shipping not authoritative, browser cannot set payment status, transactional/idempotent order creation, immutable snapshots, server admin checks, source-free products, no client secrets.
- Document real backup/recovery expectations and current official Supabase plan behavior without pretending backups are enabled; include hooks for future error tracking/uptime monitoring, health checks and PII-safe logs.
- Preserve old prototype only as reference during migration, then remove obsolete active runtime files and stale README paths; final repo has one storefront. Review original master prompt and coverage map, verify no requirements were dropped, no secrets committed and no fake payment UX.
- Run actual dependency install, lint, typecheck, unit/integration/E2E when environment permits and production build; fix failures and report genuine limitations/credentials. Avoid forced history changes or unnecessary file deletion.

## Scope

Deployment artifacts, README/architecture/backup docs, production verification, secret/legacy audit and final report.

## Out of scope

Actual Cloudflare/DNS/VPS changes without owner access; future payment gateways, coupon/review/customer/notifications/courier/invoice/analytics systems.

## Dependencies

Goals 01–09 and the master-prompt coverage audit.

## External requirements

For an actual deployment: VPS SSH access (owner-provided secret), domain/DNS or Cloudflare authorization/token (secret), production `DATABASE_URL`/Supabase Auth/Storage credentials and confirmed public site URL. These are not needed to prepare reviewable deployment artifacts. Official current Supabase backup and Next/Docker guidance must be verified online.

2026-10-11: Owner confirms domain already purchased, requests cheapest/free hosting research and full production readiness. See `../PRODUCTION_SERVICES.md` for the researched account/tool/credential inventory, cost boundaries and acceptance gates. Hosting/backend selection remains open: paid 8 GB-class VPS with self-hosted Supabase is a lower recurring-cost candidate; managed Supabase remains the existing runbook until an alternative is selected and implemented/validated. Reliable SMTP, off-site DB+photo recovery, external monitoring/error alerts, CI and courier/COD operations are part of production acceptance. No provider purchase/setup is complete merely because it is listed.

## Files expected to change

`Dockerfile`, `.dockerignore`, reverse-proxy examples, deployment/backup docs, `README.md`, `ARCHITECTURE.md`, `next.config.*`, old root HTML/JS/CSS cleanup, status/goal docs.

## Implementation checklist

- [x] Independent CI/strict runner/runtime and ops/SMTP/scheduler code; local schema/preflight/restore/Docker/nginx checks.
- [x] Targeted esbuild remediation and checksum/version guarded braces string-pattern mitigation with regression.
- [ ] Upstream-compatible remediation of reported full-tooling advisories and ESLint/React-plugin support.
- [ ] Actual GitHub execution, host/domain/mail/independent upload/full-service restore and operator inbox acceptance.

- [x] Research production service/tool inventory, free/commercial hosting limitations and cheapest viable hosting candidates; record owner-confirmed purchased domain (2026-10-11).
- [ ] Select and verify actual hosting/backend quote, region, capacity and access; implement selected operations plan from `../PRODUCTION_SERVICES.md` (self-hosted backend requires additional artifacts and acceptance tests).
- [ ] Verify SMTP/admin recovery, monitoring/error alerts, DB+photo backup/restore, CI/rollback and courier/COD operating process against the production acceptance gates.

- [x] Build/test Docker standalone artifact (non-root runtime, public/static copies; DB-backed health smoke with disposable PostgreSQL 17 passed).
- [x] Document Nginx, Cloudflare, managed DB and secret setup (template only; no live credentials/deploy).
- [x] Document migrations, rollback/recovery and honest backup expectations (restore drill not yet executed).
- [x] Rewrite README and add architecture/invariant document (revisit as unfinished goals land).
- [x] Publish current in-progress project to existing GitHub `Monechai-website/main` via fast-forward (historical action; owner later requested deletion). Not a production launch.
- [x] Delete old public repo and publish current project to a newly created private same-name repo with fresh history. Deleted old, verified new private `main`, one-root history and 158 matching project files. Vercel separate.
- [x] Remove obsolete static runtime (2026-10-10 owner explicitly requested cleanup before unfinished visual parity; Git history keeps the reference, JSON preserves seed data).
- [ ] Review original master specification and coverage, scan secrets/fake claims/payment paths.
- [ ] Run and record final gates/build/E2E and deployment smoke tests where possible.
- [ ] Mark all goals DONE only when their acceptance criteria actually hold; produce final report.

## Validation / tests

Dependency install, lint, typecheck, unit/integration, Playwright, production build, Docker build/run and health check where tools/access permit; manual docs/secret/legacy audit.

## Definition of done

One real storefront/admin app is buildable and deployable by documented commands, all required goals are DONE, and actual test/build/deployment limitations are disclosed.

## Work log

2026-10-11 latest independent milestone: Node22.23.3 clean npm ci/postinstall,50/50 strict zero skips, production4/4 sequential, lint/typecheck/build/postbuild/no-drift, local preflight16 RLS/13 migrations, real app DB/photo restore16 tables/1 image, Docker build/UID1001/assets/health and dummy-cert nginx syntax pass. Targeted esbuild override removed4 moderate advisories; reported5 high braces chain remains with reviewed bounded parser mitigation, regression and deliberately failing full audit gate. ESLint10 lacks current React-plugin peer support, so no unsupported force upgrade. CI YAML parses but no GitHub run. No provider/SMTP/host/DNS/off-site/real gateway actions. Owner setup checklist is the next dependency; all independent checks done.

2026-10-11 final-check dependency: new enforced owner MFA must also govern direct Supabase Storage writes. Tightened private storage admin helper to require trusted auth.jwt AAL2 plus existing membership; local SQL regression verifies AAL1 owner upload/delete denied, AAL2 nonmember denied, AAL2 owner allowed, membership revocation denied. Small05/06 security dependency under10; actual provider policy application remains external.

2026-10-11 access clarification: docs/ACCESS_REQUIRED.md records all current versus planned credentials/account access and unfinished integration code. Official Supabase/Cloudflare credential docs refreshed. Live read-only GitHub check: current gh user Sami-754, target PUBLIC and pull/READ only, push/admin false; verify intended privacy and authorized write/settings access before CI/release. No remote mutation or paused implementation resumed. Host/backend remains unselected and SMTP/bot/backup/monitoring need actual setup/implementation/acceptance.

2026-10-11 pause handoff: 17-file legacy cleanup, JSON seed preservation, standalone startup assets and navigation attribute repaired/validated. Remaining A18 compatible dependency fixes (last audit nine dev advisories, zero production), A21 strict CI/runtime/executable preflight/recovery/alerts and real deployment/restore acceptance. Cheapest hosting/services/access research is in docs/PRODUCTION_SERVICES.md; route unselected and no purchase/setup/deploy performed. Owner asked to continue tomorrow; resume 03 first.

2026-10-11: Wrote `docs/PRODUCTION_SERVICES.md` from then-current provider docs. Published starting prices are research, not a selected or purchased plan. Domain purchased per owner. No provider signup or deploy. A01 was completed later the same day under goal 08; do not restart it from this note.

2026-10-10: Removed 17 obsolete prototype files after saving the demo seed as JSON, fixed standalone asset startup, and recorded the audit. Post-cleanup lint, typecheck, build, 28/28 tests and 1/1 browser case passed that day. Later local fixes are in the audit resolution table. The open-findings list from that day was removed so it would not be followed again.

2026-10-08: Added the Node 22 Dockerfile, deployment runbook, backup notes, Nginx example and architecture doc. A disposable database smoke returned health 200. Docker image build served login without a database and health 503, as expected. No live restore. Git history was republished as a fresh private repository at `e1546f3`. A 2026-10-11 read of the same GitHub repo reported PUBLIC and READ-only for the current CLI user; that later check is the one to trust. The static prototype is no longer in the working tree.

## Result

BLOCKED_EXTERNAL/UPSTREAM. Independent code/artifacts/checks completed: Node22.23.3, strict CI/zero-skip tests, reviewed tooling mitigation, preflight/health, encrypted app DB/photo export/isolated restore, SMTP/scheduler templates, Docker nonroot startup/assets and nginx syntax. Production audit0; full audit5 high unpatched braces-chain entries still block full security gate; no forced downgrades/disabled checks. Actual hosting/DNS/mail/CI/off-site/full-Supabase recovery acceptance and all required goals remain incomplete. See OWNER_SETUP_CHECKLIST.md.
