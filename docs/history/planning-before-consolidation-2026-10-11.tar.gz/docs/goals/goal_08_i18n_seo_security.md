# Goal 08 — Internationalization, SEO and security

## Goal

Finish bilingual content, truthful production claims, discoverability and public/admin security.

## Why this exists

The prototype uses scattered HTML injection and unsupported marketing claims; a public commerce app also needs strong validation and safe metadata.

## Requirements from the master prompt

- Preserve English/Bangla using structured Next-compatible dictionaries, localized category/product fields and optional client preference without client-rendering the entire app or arbitrary `innerHTML`.
- Dynamic titles/descriptions/canonical/Open Graph, unique product URLs, sitemap, robots and accurate Product JSON-LD. No fake review/rating structured data. Configure site URL and safe optimized storage images.
- Audit/remove or ground all prototype claims: 5000+ customers, sold counts, ratings, verified testimonials, artificial timer/flash sale, unverified 24h delivery/exchange/quality promises and unsupported discounts. Future review/promotions components may remain data-driven but must not pretend seed data is real.
- Centralize/confirm WhatsApp and contact values, encode URLs safely, and make WhatsApp supplemental to a real DB order; messages may use a persisted order number but opening WhatsApp never creates success.
- Review hostile input/validation, safe SQL/rendering, XSS/CSRF, secure cookies, authorization, security headers, body/request limits, safe errors, server secret boundaries and PII-safe structured logging. Add reasonable replaceable public-checkout anti-abuse (rate throttling/honeypot/idempotency); no immediate CAPTCHA without need.
- Cover missing product, unavailable, no results, empty, validation, failed order, DB/server failure and unauthorized admin states with intentional messages.

## Scope

Locale architecture, SEO metadata/routes/schema, security/abuse/privacy pass, truthful content and WhatsApp cleanup.

## Out of scope

Independent full review platform, genuine timed promotion engine without business data, online gateway integration.

## Dependencies

03 public pages, 04 checkout, 06 catalog management and 07 settings.

## External requirements

`NEXT_PUBLIC_SITE_URL` public canonical production URL when known; confirmed store contact values and any verified policy/claim wording from owner. Security controls can be coded with local/test defaults while these details are pending.

## Files expected to change

`src/i18n`, `src/app/sitemap.ts`, `src/app/robots.ts`, metadata files, `src/features/checkout/abuse`, `src/lib/security`, `src/components`, settings and security configuration.

## Implementation checklist

- [x] A16 independent policy authoring/pages/versioned immutable consent code; changed-policy rejection and retries tested.
- [ ] Owner actual policies/ETA/rates/contact/translations and notification acceptance.

- [x] A01/A11/A12/A14: all-table RLS/revokes, durable counters/budgets/body deadlines and outage fallback locally validated.
- [x] A19 local code: crawlable EN/BN URLs, alternates/canonical/metadata and remaining localized labels/copy. Bangla phone digits repaired under 04.
- [ ] A16: configurable policy pages/acceptance and approved delivery/returns/privacy/terms/contact/ETA information. Receipt/tracking implemented under 07.
- [x] A20 local code: configured store name in public branding/metadata and accessibility closure. Admin semantics/filters/attributes and checkout field errors repaired.
- [x] A09 cross-goal check: validate effective-price structured data after goal 03 final pricing gates.
- [x] A15: closed by owner NEW PRODUCTS ONLY scope; NewCondition remains accurate.

- [x] Implement structured English/Bangla UI, preference and localized catalog output.
- [ ] Verify localized home/shop/product/cart flow against published rows in a database; review mobile layout in both languages.
- [x] Add canonical/OG/sitemap/robots/Product JSON-LD without fake claims.
- [x] Audit the active Next storefront for false metrics, reviews, countdowns and delivery promises; none remain in the active routes. The legacy prototype was removed under goal 10 on 2026-10-10.
- [x] Centralize WhatsApp/contact URLs from database settings and safely encode optional messages.
- [ ] Confirm owner-provided production contact values and canonical domain.
- [ ] Audit authorization, input, cookies, CSRF, XSS, errors, limits, logging, headers and secrets.
- [x] Add durable PostgreSQL visitor/IP quotas, honeypot and duplicate/recovery protections; actual trusted-IP/proxy deployment still needs verification.
- [ ] Verify error/empty/unavailable states and run quality gates.

## Validation / tests

Locale and SEO output tests, security/abuse tests, secret/PII scan, manual English/Bangla and link checks; lint/typecheck/build.

## Definition of done

Both languages work on required routes, metadata is accurate, unsupported claims are absent, and public/admin security checks are verified without leaked PII/secrets.

## Work log

2026-10-11 local slice validated: route prefixes/alternates/metadata/sitemap, brand propagation, optional Bangla variant labels, no-referrer/private production receipts, policy pages/versioned admin publishing/mandatory consent and immutable history. Migration 0011 applied/no-drift; 43/43 zero skips, lint/typecheck/build/postbuild passed; production E2E 4/4. Browser found persistent root-language and prefetch cookie races, fixed through locale shell/document sync and document-only preference updates. Reviewed EN/BN 390/1280 shop screenshots, widths and dialog Escape/focus; actual photos/admin provider and broad accessibility scan remain under 09. Owner policies/notification workflow/contact/domain/translations remain pending.

2026-10-11 owner resumes independent fixes: persisted STORE_OPERATING_PLAN.md and goal 11 dependency. Leave current catalog records intact. Implement locale URLs/metadata, configured branding, policy authoring/acceptance and private receipt protections; business copy/credentials follow owner handoff. No invented policies or providers.

2026-10-11 pause handoff: security A01/A11/A12/A14 repaired locally and Bangla phone digits repaired under 04. Remaining work: A19 locale URLs/metadata/copy, A16 policy/configuration and A20 brand/accessibility. A09 pricing gates precede resumption here. Owner policies/rates/ETA/contact/canonical domain and live security acceptance remain external. Owner requested continuation tomorrow; no active goal during break.

2026-10-11 security slice: migration 0006 enables RLS and revokes API grants on the application tables, with a granted-role regression. Durable visitor/IP counters, preview/catalog throttles, slow-body deadlines, settings fallback and bounded database failures passed 31/31 after an ISO date fix, plus lint, typecheck, build and no-drift. Checkout recovery was finished under goal 04. Live project and proxy verification remain external.

2026-10-08: English/Bangla dictionaries, preference cookie, sitemap/robots, Product JSON-LD and baseline security headers landed. The static prototype that still held old marketing claims was removed on 2026-10-10. Crawlable locale URLs, policy pages and configured branding remain open.

## Result

BLOCKED_EXTERNAL. EN/BN routing/metadata/brand/policy revision/consent/private-receipt/security code passes local unit/production browser/WCAG checks. Real contact/domain/policies/catalog translations and backend/proxy acceptance remain owner requirements.
