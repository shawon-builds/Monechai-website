# Goal 05 — Admin authentication and authorization

## Goal

Protect a single in-app admin area with Supabase Auth plus explicit admin membership.

## Why this exists

Authentication alone must not grant access to product, order or settings mutations.

## Requirements from the master prompt

- Use Supabase Auth for admin login; no public customer accounts. Add `admin_members` whitelist table with appropriate FK/identity, and require both valid session and membership for all privileged server reads/mutations.
- Implement `/admin` protected layout/login and unauthorized states. Use current supported SSR/session/cookie flow, secure cookies and CSRF-aware mutation architecture; service secrets never enter browser bundles.
- Document and verify first-admin bootstrap without fabricated account/password. Admin URL/auth credentials need owner setup at the correct point.
- Keep admin in the same Next.js application; avoid separate admin app or client-only authorization.

## Scope

Supabase Auth clients/session handling, whitelist schema/migration, admin login/protected shell, server-side authorization helpers and bootstrap procedure.

## Out of scope

Product CRUD (06), order CRUD (07), customer accounts, permission hierarchy beyond a simple admin whitelist.

## Dependencies

01 foundation/database setup; 02 may share migration conventions.

## External requirements

- `NEXT_PUBLIC_SUPABASE_URL` — public project URL from Supabase Dashboard → Project Settings → API.
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` — public publishable key from the same API settings.
- Owner-created, confirmed Supabase Auth user/email and project SQL Editor access to insert that user's ID into `admin_members` after migration. `DATABASE_URL` (SECRET; Dashboard → Connect) needed for runtime membership reads; `DIRECT_URL` (SECRET) if migrations use a pooler. No service-role key required.
- A server-only key is requested only if the implementation genuinely needs privileged Supabase operations; name `SUPABASE_SERVICE_ROLE_KEY`, secret, from Project Settings → API. Never put it under `NEXT_PUBLIC_*`.

## Files expected to change

`src/db/schema/admin.ts`, migrations, `src/features/admin/auth`, `src/app/admin`, `src/lib/supabase`, `.env.example`, bootstrap docs.

## Implementation checklist

- [x] Live separate Monechai backend with13 migrations/16 RLS tables, checked scoped runtime role, initial Auth settings and products bucket/policies.
- [x] Privately configure public project key/origin and scoped runtime app environment; production build/postbuild passes.
- [ ] **PAUSED/PENDING:** user logs into friend's intended account; verify access to exact project. Designated owner email unknown — add later.
- [ ] Real confirmed owner identity/membership, personal TOTP and actual login/revocation acceptance.
- [ ] Custom SMTP dependency: dashboard requires it before editing reset email template; six-digit settings alone do not complete recovery.

- [x] Independent owner recovery/TOTP/AAL2/rate-limit code and offline failure-policy tests.
- [ ] Live SMTP recovery template/mailbox, actual MFA enrollment/login/logout/revocation acceptance.

- [ ] Production recovery/MFA acceptance: app email-code/TOTP/AAL2 flow exists; configure owner SMTP/template and verify actual backend.
- [ ] Cross-check real anon/authenticated table denials after A01 hardening and complete live session checks.

- [x] Add `admin_members`, generated migration, local apply and RLS/revokes.
- [x] Implement Supabase SSR session flow with Next 16 Proxy refresh; live Auth verification pending.
- [x] Enforce verified Auth user + DB whitelist in reusable server helper and current admin data page; goal 06/07 must call guard per operation.
- [x] Build login, protected page/layout and unauthorized states.
- [x] Document first-admin bootstrap (`docs/admin-bootstrap.md`) and test offline allow/deny + local DB lookup; **blocked:** real Supabase login, nonmember and revocation browser verification require owner project/user.
- [x] Run local gates and document credential blockers; **blocked:** live login test.

## Validation / tests

Auth/membership tests for unauthenticated, authenticated non-admin and admin requests; manual login against actual Supabase project; lint/typecheck/build.

## Definition of done

Only a real signed-in whitelisted user can reach admin data or invoke privileged mutations; bootstrap is repeatable and documented.

## Work log

2026-10-11 user pause/handoff: user says this is friend's project and owner email unknown; asks to log all Supabase points and remaining work before signing into friend's Gmail/Supabase and continuing later. Live work stopped; goal BLOCKED, no active goal. [Complete Supabase handoff](../SUPABASE_SETUP_HANDOFF.md) records exact project/account check, applied13 migrations/16 RLS tables, scoped runtime ACL/connection checks, live5MiB WebP products bucket/policies, initial Auth settings, private environment files and build/postbuild success. Actual owner identity/MFA/session/Storage/customer acceptance and SMTP/template remain. SMTP template editing is blocked by dashboard until custom SMTP is configured; no real email sent or owner user created. No app HTTP smoke performed after environment build.

2026-10-11 separate Monechai project lmrdvenrchsnueztzcdi created in authorized organization, FREE/NANO Singapore ap-southeast-1, Healthy. Automatic new-table API grants disabled; automatic RLS enabled. New DB password privately saved ignored mode600; old Lead remains untouched. Database/schema/Storage/Auth configuration follows.

2026-10-11 target correction: owner confirms old Lead project needed, switches to organization lpbdravwzduphzmfnlsj (Sami's org FREE, empty). No SQL/provider setting/credential changes on old project. Prepare separate Monechai backend here.

2026-10-11 owner authorizes live Supabase project setup through authenticated Kimi dashboard, project syzifxmdbfsfistwapkq. Restoration complete. Begin existing schema/data inspection; reviewed migration01/02 dependency precedes owner/Auth/Storage configuration. Owner identity/password/MFA and exact domain/SMTP/business values must not be invented.

2026-10-11 local security code validated: owner email-code recovery, enrolled TOTP/AAL2 checks before password update, global-session revoke request, TOTP enrollment/verification and mandatory AAL2 on every privileged operation. Login/recovery/MFA have durable attempt budgets; proxy fetch is bounded. Focused2/2 and full45/45 zero skips, typecheck and build/postbuild passed (lint warning subsequently fixed). Supabase source confirms listFactors.totp is verified-only; all is used for unverified enrollment. No owner Auth/SMTP connected; no message/enrollment performed. Setup template and live acceptance are documented in admin-bootstrap.md.

2026-10-11: Active independent owner recovery/MFA code slice after validated 08. Owner supplies real account/SMTP/setup after code checks; provider acceptance still blocked. Read current official Supabase MFA/recovery guidance.

2026-10-11 access clarification while paused: owner Supabase URL/public key/DB/confirmed user/Storage configuration still unavailable. Basic login/whitelist code and local tests exist; actual Auth sessions/revocation remain unverified. Production recovery/MFA also require implementation and SMTP, not just keys. Exact access/current supported variables are in docs/ACCESS_REQUIRED.md; no owner password/service-role key requested and no app implementation resumed.

2026-10-10: State set to BLOCKED for live owner Auth acceptance. Per-read and per-action guards already existed. Migration 0006 later revoked client API access on the other application tables; applying that migration on the owner's project is still unverified.

- Proxy matcher also includes future `/api/admin/*` handlers for cookie refresh; each API must still call `requireAdmin` before privileged operations. Lint/typecheck/build rerun after this change passed.
- First-admin setup documented in `docs/admin-bootstrap.md`: exact email-only owner SQL Editor operation checking `auth.users`, idempotent membership grant, revocation and login/deny verification steps; no privileged API key needed. Standalone no-Auth-config smoke: `/admin` 307 to `/admin/login`, login 200; with local DB homepage also 200. Live Supabase login remains blocked by owner access.
- Temporary PostgreSQL 17 accepted migration 0002 (including RLS/revoke); DB membership allowed/denied tests and offline policy passed alongside existing tests (12/12), lint/typecheck/build and Drizzle no-drift. Initial test import of Next navigation failed under react-server condition; moved membership lookup to a separate Next-independent module and reran successfully. Live Supabase Auth session has not been tested.
- Added 0002 whitelist UUID primary key without a PostgreSQL FK to `auth.users`: local portable PostgreSQL lacks the Supabase-managed `auth` schema; bootstrap must verify the identity in `auth.users` and insert only an existing ID. No client grants/privileged Supabase API. Added SSR proxy and per-request server auth; initial typecheck exposed SSR `headers` as record rather than `Headers`, fixed. Generate/lint/typecheck/build passed; live Auth not tested.
- Started goal 05 after locally closing 04. Next 16.3.8 auth guide warns layouts are not sufficient authorization boundaries; use a server data-access guard on every privileged read/mutation. Supabase SSR guide recommends per-request clients, `getClaims()`/`getUser()` (never unverified `getSession()` identity), and Proxy for cookie refresh with no-cache headers. Live login is owner-dependent.

## Result

BLOCKED_EXTERNAL / user-requested pause. Independent owner security code and prior local tests pass. Separate live backend/schema/ACL/runtime role/Storage/initial Auth are configured and production build/postbuild with local env passed. Designated owner email/user is pending; actual MFA/login/revocation/photo/customer acceptance and custom SMTP recovery template remain. No owner identity or email created/sent. Resume from ../SUPABASE_SETUP_HANDOFF.md after user account switch and explicit resume.
