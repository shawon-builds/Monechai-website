# Goal 04 — Cart, shipping and real COD checkout

## Goal

Let guests place real, transactional Cash on Delivery orders with authoritative totals, safe inventory updates and a private success route.

## Why this exists

Current checkout trusts browser calculations, stores PII/order data in localStorage and can show success without database persistence.

## Requirements from the master prompt

- Guest cart may persist only product/variant IDs and quantities in browser storage. Re-query products/variants at preview and submit; explain deleted/unpublished items, changed price/stock and unavailable variants. Do not store customer PII permanently in localStorage.
- Implement `/checkout` and `/order/[publicToken]/success`, cart drawer/items/quantity/empty cart/form/summary. Success must read a real DB order by a non-enumerable public token and avoid leaking another customer's PII; failed database writes must never show success.
- Server validates IDs, quantities, Bangladesh phone normalization, name/address/area/note and payment method. Browser prices, shipping, discount, stock, payment status and order status are never authoritative.
- Server retrieves current published product/variant data, computes exact integer-money subtotal, configurable Inside/Outside Dhaka shipping and optional free-shipping threshold, valid discounts (if any) and total; checkout preview uses the same shipping domain but final server result wins. Test boundaries.
- Drizzle schema/migrations for `orders`, `order_items`, `shipping_zones` and needed idempotency fields. Persist immutable item snapshots: product/variant references, name, SKU, chosen attributes, quantity, unit price and line total. Use robust internal IDs plus safe customer-facing number/token.
- Use one PostgreSQL transaction to create complete orders/items and reserve/deduct stock; rollback all on failure, prevent overselling via atomic update/locking, and protect retries/double-click with a documented idempotency strategy.
- Start with real COD only. Keep payment method separate from status (`pending`, `paid`, `failed`, `refunded`); browser cannot mark paid. Define clean future payment provider boundary (`createPayment`, `verifyPayment`, `handleWebhook`, `refundPayment`) without fake bKash/Nagad; future gateway success requires server verification/signed webhooks and merchant credentials.
- Provide intentional validation, stock, empty cart, failed order and DB failure states; lightweight duplicate/abuse hook to be completed in 08.

## Scope

Guest cart, shipping domain, order schema/services, COD checkout, inventory, idempotency, success route and domain/integration tests.

## Out of scope

Real bKash/Nagad (future credentialed integration), admin order UI (07), full abuse/security audit (08), broad Playwright suite (09).

## Dependencies

02 catalog/stock/money and 03 storefront shell.

## External requirements

`DATABASE_URL` (SECRET; Supabase Dashboard → Connect → transaction pooler) for live checkout; `DIRECT_URL` (SECRET; Supabase Dashboard → Connect → direct/session connection) or `DATABASE_URL` for the owner-run shipping CLI. Owner must provide actual Inside Dhaka and Outside Dhaka delivery charges, and decide whether a free-shipping threshold applies; business figures are not secrets, but must not be invented. Configure them as integer poisha via `SHIPPING_INSIDE_DHAKA_MINOR`, `SHIPPING_OUTSIDE_DHAKA_MINOR`, optional `SHIPPING_FREE_ABOVE_MINOR` (all server CLI input, **not** `NEXT_PUBLIC_*`). No merchant credentials required for COD. If the owner later requests bKash/Nagad, obtain real merchant API credentials/webhook secret first; do not expose unfinished methods.

## Files expected to change

`src/db/schema/orders.ts`, migrations, `src/features/cart`, `checkout`, `orders`, `inventory`, `shipping`, `payments`, `src/app/(store)/checkout`, `src/app/(store)/order`.

## Implementation checklist

- [x] A04/A06/A07/A08/A13: durable retry recovery, cart limit/storage handling, shipping geography and checkout lock scope.
- [x] Goal 03 pricing dependency: quote fingerprint/PRICE_CHANGED review flow validated 2026-10-11 with final DB/browser/full build gates.

- [x] Build ID/quantity-only guest cart and refreshed summary (preview route re-queries catalog, unavailable lines disable order).
- [x] Add order/item/shipping schema and migration with constraints/indexes (0001 applied to local test DB).
- [x] Add validated checkout and Bangladesh phone normalization in the service, UI and API.
- [x] Add one authoritative shipping service and exact totals (owner must configure zone fees before checkout can succeed).
- [x] Implement transactional order/items/stock updates with concurrency safety (local DB test passed).
- [x] Implement idempotency and safe public identifiers (DB-backed retry lock and random 256-bit token; local test passed).
- [x] Expose COD only; speculative unused payment interface removed during cleanup, no fake payment integration.
- [x] Build real success/error flow and remove browser-local order success (token DB lookup; legacy success URL redirects to checkout).
- [x] Test pricing tampering, invalid/unpublished products, stock, rollback, duplicate requests and persistence (domain, DB and browser tests).
- [x] Run quality gates; update docs/status.

## Shipping configuration (owner action)

After applying migrations, obtain approved courier/store charges from the owner. Convert taka to integer poisha (৳1 = 100 poisha). Set both `SHIPPING_INSIDE_DHAKA_MINOR` and `SHIPPING_OUTSIDE_DHAKA_MINOR` to the approved charges; set optional `SHIPPING_FREE_ABOVE_MINOR` to the owner's chosen subtotal threshold, or leave unset to disable free shipping. Run `npm run shipping:configure` to preview **without database changes**, then `npm run shipping:configure -- --apply` with the same environment values and a server-only `DIRECT_URL` (or `DATABASE_URL`). This upserts both zones atomically. Do not commit the DB URL or claim any test-only fee is the production rate. Until configured, checkout preview cannot produce a total and order creation returns a service-unavailable error. Goal 07 can replace this CLI workflow with authorized admin business settings.

## Validation / tests

Domain tests for money/shipping/phone/checkout/totals/stock; PostgreSQL integration tests for persistence, rollback, concurrency and idempotency; browser COD journey when test environment is ready; lint/typecheck/build.

## Definition of done

Real COD orders persist once with correct server prices/shipping, snapshots and stock; invalid or failed orders cannot reach success; customer token is non-enumerable and private.

## Work log

2026-10-11 pricing dependency validated (owner resumed): stale-quote PRICE_CHANGED + refreshed second confirmation covered by price-review E2E 1/1 and full 39/39; checkout/recovery E2E 2/2 rerun with quote changes; goal 04 DONE locally again. Live fees/admin/provider acceptance remains in later goals.

2026-10-11 pricing dependency/pause: while goal 03 fixes A09, preview/submit share a fingerprint of server prices/quantities, delivery area and totals. Stale values reject before order creation and client refreshes/requires another confirmation; existing order recovery runs first. Focused 10/10 and existing E2E 2/2 passed before final test additions. New pricing browser case/full final gates pending. Owner asked to continue tomorrow; goal 04 PAUSED for this dependency. Earlier recovery/cart/delivery milestone remains validated; resume/validation owned by 03.

2026-10-11 repair validation: 34/34 full local tests; final focused area/cart/domain/order 10/10, E2E 2/2 incl. response-lost/reload recovery, lint/typecheck/build/diff/no-drift passed. First E2E selector failure and one fixture-overlap focused run are recorded honestly in PROJECT_AUDIT.md; both reruns pass. No production fees or area boundaries invented. Goal 04 local milestone repaired; moving to 07 cancellation/returns.

2026-10-11: Active for A04/A06/A07/A08/A13. Implement cookie-backed retry recovery without stored PII, validated cart writes/storage fallbacks, server-owned delivery-area-to-zone mapping and shared settings lock. Approved delivery areas require a small goal 07 settings dependency; no business coverage/rates guessed.

2026-10-10: Reopened as PAUSED for checkout findings in PROJECT_AUDIT.md: client retry UUID does not survive reload, cart edits can exceed the 100-unit cap, storage failures are uncaught, shipping zone is self-selected without geography validation, and singleton settings FOR UPDATE serializes checkouts. Server same-key idempotency/stock tests still pass; client recovery requires new regression coverage.

2026-10-06: Built migration 0001, the preview API, ID/quantity cart, checkout UI, COD success route, origin guard, cart drawer and owner shipping CLI. Local gates that day were 10/10 tests, 1/1 Chromium checkout and a production build. A forced mid-order database failure rolled the order back. No production shipping rates were invented. The quote-fingerprint work above is the part still waiting for final validation.

## Result

**DONE locally 2026-10-11 (pricing dependency validated);** earlier audit repairs validated 2026-10-11; live fees/admin/provider acceptance remains in later goals. Earlier results below describe the original milestone.

Goal 04 local implementation complete. Guests can add only variant IDs/quantities to browser storage, inspect a focus-managed cart drawer and server-refreshed checkout, and place COD orders with validated Bangladesh contact/address details. Migration 0001 adds configurable shipping, orders and immutable item snapshots; the transaction locks current product/variant/zone data, calculates exact server totals, writes order/items, conditionally decrements stock, and enforces retry idempotency and safe random public tokens. Success renders only for persisted orders, without customer PII. No real bKash/Nagad integration is exposed.

Validated on dedicated local PostgreSQL: migration and shipping CLI apply/cleanup, 10/10 unit/integration tests (including forced post-insert DB error rollback, concurrent last-unit orders, unchanged/changed key retries, unpublished products, tampering/phone/shipping), 1/1 Chromium Playwright E2E (drawer, keyboard, invalid phone, changed stock, COD success), lint/typecheck, Drizzle no-drift and production build. Standalone smoke verified checkout 200, nonexistent token 404, legacy redirect, valid vs foreign Origin behavior.

**Production rollout still requires owner action:** real delivery fees and an optional free-shipping threshold, plus a live database URL. No rates were invented. Later goals added local abuse limits, admin settings and order management. Expanded visual coverage and deployment acceptance remain in goals 09 and 10. Full Chromium ran the checkout browser test.
