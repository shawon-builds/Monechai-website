# Goal 11 — Real online payments

## Goal

Integrate one owner-approved merchant payment gateway alongside COD, with verified financial and inventory outcomes.

## Why this exists

The owner asked how online payment fits into guest checkout. Current code/database deliberately accept COD only; gateway functionality must be real and verifiable.

## Requirements from the master prompt

Latest owner discussion: preserve guest checkout and protected owner admin; online payment does not require a Monechai buyer account. Server totals/payment status remain authoritative. No fake bKash/Nagad integration. See [store operating plan](../STORE_OPERATING_PLAN.md).

## Scope

One selected provider, pending order/payment attempt lifecycle, hosted checkout handoff, provider validation/notifications, reconciliation, duplicate protection, failure/expiry inventory release and accurate success/refund states.

## Out of scope

Multiple speculative gateways, customer accounts, stored card/wallet credentials, provider onboarding/purchase without owner action, phone OTP for future customer order editing/history.

## Dependencies

04 transactional checkout; 05 server authorization; 07 order/payment state management; 08 request/privacy controls; 09 meaningful regression harness.

## External requirements

BLOCKED: owner gateway choice/launch requirement, approved merchant onboarding, sandbox and production API credentials, verified callback hostname, settlement/refund rules. Exact variable names depend on the chosen provider and must be documented before setup. Secret keys are server-only. Official current API documentation is required. No provider selected; do not invent credentials.

## Files expected to change

`src/features/checkout`, payment domain/adapter/routes, order/payment schema/migrations, checkout UI, admin payment/reconciliation UI, tests and operations docs.

## Implementation checklist

- [x] Persist required guest/privacy/provider validation boundaries and dependency ownership.
- [ ] BLOCKED: choose/approve provider and obtain actual sandbox merchant access.
- [ ] Design provider-specific payment attempts, immutable references and stock reservation/expiry strategy.
- [ ] Implement initiation/server verification and authenticated validated notifications with idempotency.
- [ ] Handle failed/cancelled/expired payments, stock release and reconciliation/refunds.
- [ ] Pass sandbox amount/order/currency tamper, lost response, duplicate callback and concurrency regressions.
- [ ] BLOCKED: verify production merchant configuration and owner-authorized acceptance.

## Validation / tests

Provider sandbox tests plus local financial/inventory invariants, hosted checkout E2E, lint/typecheck/tests/build, reviewed reconciliation/expiry recovery. Real payments require separate owner authorization.

## Definition of done

Chosen provider works with guest checkout; only server-verified matching transactions mark payment paid; retry/failure/expiry cannot double charge/order or leak/reserve stock indefinitely; owner/provider acceptance and operating procedure verified. If owner chooses COD-only launch, document that scope decision explicitly rather than claiming this integration complete.

## Work log

2026-10-11: Created before implementation. Owner wants independent code work first, then consolidated setup requirements. Provider choice/access is unavailable; COD remains active. No gateway package, fake UI or payment credentials introduced.

## Result

BLOCKED on provider selection/merchant access. Planning complete; no online gateway implemented.
