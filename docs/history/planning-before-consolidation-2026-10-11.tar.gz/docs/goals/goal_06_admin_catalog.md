# Goal 06 — Admin catalog and image storage

## Goal

Let an authorized owner create, edit, publish and image products without editing source code.

## Why this exists

The core owner journey ends only when new products appear in the storefront from database/admin actions.

## Requirements from the master prompt

- Implement `/admin/products`, `/admin/products/new`, `/admin/products/[id]` and `/admin/categories` with create/edit, publish/unpublish, safe delete/archive, category/SKU/price/compare-at/stock/variant/featured/localized English/Bangla fields and usable validation/errors.
- Support product #25/#100/#1000 without code edits. Every mutation verifies server-side membership and invalidates relevant Next.js catalog/home cache using current supported APIs.
- Use Supabase Storage by default behind an image-storage interface that could later target S3/R2. Admin can upload/delete/reorder/set-primary. Validate MIME, supported format, file size and storage object ownership; never expose privileged storage credentials to the browser. Configure Next image handling for storage URLs and do not use random third-party imagery as permanent production product photos.
- Preserve safe integer money and stock constraints; avoid unintended edits to historical order-item snapshots.

## Scope

Admin product/category forms, mutations, storage adapter, image management and cache invalidation.

## Out of scope

Order management (07), customer accounts, speculative media-processing pipeline.

## Dependencies

02 catalog, 03 storefront queries, 05 admin authorization.

## External requirements

Supabase project URL/publishable key and Storage bucket access. A server-only `SUPABASE_SERVICE_ROLE_KEY` may be necessary for privileged storage operations; if used, obtain it from Supabase Dashboard → Project Settings → API and keep it secret. Real product photos require owner-provided assets/content.

## Files expected to change

`src/app/admin/products`, `src/app/admin/categories`, `src/features/admin/catalog`, `src/features/catalog/storage`, `src/lib/supabase`, schema/migrations if needed, image config.

## Implementation checklist

- [x] A02/A10: finish media management and reject invalid/nonexistent primary images or products without active variants.

- [x] Build validated category CRUD (create/edit/delete-empty with server guard and local DB test; live Supabase verification pending).
- [x] Build product create/edit/archive/publish/featured/variant/stock flows (local DB tests; live owner Auth and Storage acceptance still blocked).
- [x] Add localized fields and exact price inputs.
- [x] Add storage abstraction and secure upload/delete/reorder/primary flows.
- [x] Revalidate affected storefront data after category/product/variant mutations; revisit for image flows.
- [ ] Verify owner add→publish→storefront path and unauthorized denial.
- [x] Run gates; update docs/status.

## Validation / tests

Admin mutation authorization and validation tests; upload MIME/size/ordering tests; manual creation of a new product that appears in storefront; lint/typecheck/build.

## Definition of done

An authorized admin can complete the primary owner product journey without changing code, including image upload and immediate storefront visibility.

## Work log

2026-10-11 final security dependency: direct Storage product writes now require trusted AAL2 and owner membership via restrictive guards; modeled SQL tests include old allow-all and deny anon/nonmember/AAL1-owner insert/delete/overwrite, preserve public photo reads and AAL2 owner upload, and enforce membership revocation. No live policy application. Existing catalog preserved; optional Bangla variant labels added under08.

2026-10-11 pause handoff: local A02/A10 media fixes and A20 catalog usability logged in PROJECT_AUDIT.md. Actual owner Auth/Storage/upload/publish/revocation acceptance remains BLOCKED. No media code changed for the owner break. Follow docs/product-images.md and ops/supabase-storage.sql when owner access is available.

2026-10-11 validation: 0009/0010 owned verified media fingerprints, bounded real image decode/re-encode, owner JWT Storage adapter/policy, upload/order/primary/remove/publish gating; active variants required and destructive edits unpublish. Added attribute rows, filters/stock and semantic fixes. Five focused media/product/SQL-policy regressions; full39/39, lint/typecheck/build/no-drift/diff/E2E2/2 pass. Real sample pixels/local adapter and SQL role model used, not a live owner bucket/session. Follow docs/product-images.md for external setup; goal BLOCKED on actual owner journey, independent 03 pricing proceeds.

2026-10-11: Active for secure media upload/manage/publish validation and A20 catalog usability. Use authenticated Supabase user policies; privileged storage key is not required for normal uploads. Add image decode/re-encode/size/ownership validation, reject missing primary object or no active variants, test local adapters/policies and maintain external live-provider boundary.

2026-10-10 audit: publishing then accepted an invalid storage key and a product with no active variants. The 2026-10-11 media slice above closed that locally. Category and product CRUD were already in place; each admin action calls `requireAdmin()`. Live owner login and bucket acceptance remain blocked.

## Result

BLOCKED_EXTERNAL. Product/media code, real pixel/hash/lifecycle regressions and AAL2 restrictive Storage SQL checks pass locally. Actual bucket/owner upload/publish/policies and real catalog assets require owner setup. Existing products preserved.
